# Selfbot v2

## Config Hooks System

The bot includes a config hook system that allows you to validate configuration changes before they are applied. This is useful for ensuring that values meet specific criteria.

### Creating a Config Hook

1. Create a method in your cog that will validate the configuration (See example 1)

2. The hook will be automatically registered when your cog is loaded.

3. Example: Creating a hook that ensures a value is less than 100 (See example 2)

Example 1:

```python
class YourCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Define hooks for this cog
        self._cog_hooks = [
            ("config_key_name", "validation_method_name")
        ]
    
    # Method that will validate the configuration change
    async def validation_method_name(self, ctx, before_value, after_value):
        # Return True to accept the change, False to reject it
        if some_validation_condition(after_value):
            return True
        else:
            await ctx.send("Validation failed: reason for failure")
            return False
```

Example 2:

```python
class LimitCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._cog_hooks = [
            ("max_value", "validate_max_value")
        ]
    
    async def validate_max_value(self, ctx, before_setting, after_setting):
        if after_setting <= 100:
            return True
        await ctx.send("Error: max_value cannot exceed 100!")
        return False
```

## Adding New Configurations

To add new configurable options to your commands, follow these steps:

1. Add your configuration to `config_specification.json` (which still uses JSON format):

   ```json
   "your_option_name": {
     "default": "default value",
     "types": ["str", "int", "bool", or "float"],
     "description": "Description of what this setting does"
   }
   ```
   
   Your settings will be stored in `config.toml` using TOML format:
   
   ```toml
   your_option_name = "default value"
   ```

2. Access your configuration in your cog:

   ```python
   class YourCog(commands.Cog):
       def __init__(self, bot):
           self.bot = bot
           self.gconf = self.bot.get_config
   
       @commands.command()
       async def your_command(self, ctx):
           # Get config with default fallback
           value = self.gconf("your_option_name", "default_fallback")
   ```

Ensure you provide sensible defaults when getting config values to handle cases where the configuration hasn't been set yet.

## Setup

1. Python 3.8 or higher is required
2. Install virtualenv if you haven't already:

```bash
pip install venv
```

## Installation

1. Clone the repository:

```bash
git clone https://git.xargana.tr/glitchy/selfbot.git
cd selfbot
```

2. Create and activate a virtual environment:

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/macOS
python3 -m venv venv
source venv/bin/activate
```

3. Install the required packages:

```bash
pip install -r requirements.txt
```

4. Edit `config.toml` with your preferred settings and add your Discord bot token. If you have an existing `config.json` file, it will be automatically migrated to TOML format when you first run the bot.

## Running the Bot

1. Start the bot:

```bash
python main.py
```

The bot should now be running and connected to Discord. You can verify this by checking the console output for the login confirmation message, or by doing .help in any channel.
