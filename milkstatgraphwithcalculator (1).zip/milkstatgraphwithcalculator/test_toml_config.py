#!/usr/bin/env python3

import tomlkit
import json
import os

# File paths
JSON_CONFIG_PATH = "config.json"
TOML_CONFIG_PATH = "config.toml"

def test_read_json():
    """Read the JSON configuration file"""
    if not os.path.exists(JSON_CONFIG_PATH):
        print(f"\n[u2718] JSON config file {JSON_CONFIG_PATH} not found")
        return None
        
    with open(JSON_CONFIG_PATH, "r") as f:
        try:
            data = json.load(f)
            print(f"\n[u2713] Successfully read JSON config with {len(data)} entries:")
            for key, value in data.items():
                print(f"  - {key}: {value} ({type(value).__name__})")
            return data
        except Exception as e:
            print(f"\n[u2718] Error parsing JSON config: {e}")
            return None

def test_read_toml():
    """Read the TOML configuration file"""
    if not os.path.exists(TOML_CONFIG_PATH):
        print(f"\n[✘] TOML config file {TOML_CONFIG_PATH} not found")
        return None
        
    if os.path.getsize(TOML_CONFIG_PATH) == 0:
        print(f"\n[✘] TOML config file {TOML_CONFIG_PATH} is empty")
        return None
        
    with open(TOML_CONFIG_PATH, "r") as f:
        try:
            content = f.read()
            print(f"\n[i] Raw TOML content (first 100 chars): {content[:100]}...")
            data = tomlkit.parse(content)
            
            # Check for new structured format with metadata and settings
            has_settings = "settings" in data
            has_metadata = "metadata" in data
            has_value_metadata = "value_metadata" in data
            
            if has_metadata:
                print("\n[i] Global config metadata:")
                metadata = data["metadata"]
                for key, value in metadata.items():
                    print(f"  - {key}: {value}")
            
            # Extract the actual settings
            if has_settings:
                print("\n[i] Using structured TOML format with [settings] table")
                settings = data["settings"]
                dict_data = {k: v for k, v in settings.items()}
            else:
                print("\n[i] Using legacy flat TOML format")
                # Exclude metadata if present in flat format
                dict_data = {k: v for k, v in data.items() if k != "metadata" and k != "value_metadata"}
            
            # Show individual value metadata if present
            if has_value_metadata:
                print("\n[i] Individual value metadata:")
                value_metadata = data["value_metadata"]
                for key, meta in value_metadata.items():
                    print(f"  [Value] {key}:")
                    for meta_key, meta_value in meta.items():
                        print(f"    - {meta_key}: {meta_value}")
                
            print(f"\n[✓] Successfully read TOML config with {len(dict_data)} setting entries:")
            for key, value in dict_data.items():
                print(f"  - {key}: {value} ({type(value).__name__})")
            return dict_data
        except Exception as e:
            print(f"\n[✘] Error parsing TOML config: {e}")
            return None

def test_write_toml(data):
    """Write data to TOML format"""
    if not data:
        print("\n[u2718] No data to write")
        return False
        
    try:
        # Create a TOML document with metadata
        doc = tomlkit.document()
        
        # Add metadata section
        from datetime import datetime
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        metadata = tomlkit.table()
        metadata.add(tomlkit.comment("Configuration metadata"))
        metadata["last_updated"] = now
        metadata["version"] = "1.0"
        metadata["migration_source"] = "test_toml_config.py"
        doc["metadata"] = metadata
        
        # Add settings section
        settings = tomlkit.table()
        settings.add(tomlkit.comment("User settings"))
        for key, value in data.items():
            settings[key] = value
        doc["settings"] = settings
        
        # Add value metadata section
        value_metadata = tomlkit.table()
        value_metadata.add(tomlkit.comment("Individual value metadata"))
        
        # Add some sample metadata for a few keys
        count = 0
        for key in data.keys():
            if count >= 3:  # Only add metadata for first 3 keys as examples
                break
                
            key_meta = tomlkit.table()
            key_meta["last_updated"] = now
            key_meta["updated_by"] = "test_toml_config.py"
            value_metadata[key] = key_meta
            count += 1
            
        doc["value_metadata"] = value_metadata
            
        with open(TOML_CONFIG_PATH, "w") as f:
            f.write(tomlkit.dumps(doc))
        print(f"\n[u2713] Successfully wrote {len(data)} entries to TOML config with metadata")
        return True
    except Exception as e:
        print(f"\n[u2718] Error writing TOML config: {e}")
        return False

def main():
    print("=== TOML Configuration Test ===\n")
    
    # Test reading JSON config
    json_data = test_read_json()
    
    # Test reading TOML config
    toml_data = test_read_toml()
    
    # If TOML doesn't exist or is empty but JSON exists, try migration
    if json_data and not toml_data:
        print("\n[i] Attempting to migrate from JSON to TOML...")
        if test_write_toml(json_data):
            # Verify the migration
            new_toml_data = test_read_toml()
            if new_toml_data and len(new_toml_data) == len(json_data):
                print("\n[u2713] Migration successful!")
            else:
                print("\n[u274c] Migration verification failed")
    
    print("\n=== Test Completed ===")

if __name__ == "__main__":
    main()