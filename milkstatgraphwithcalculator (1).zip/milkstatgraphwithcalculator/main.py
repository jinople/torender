import discord
from discord.ext import commands
import asyncio
import os
from dotenv import load_dotenv
from log import logger
import signal
import argparse

# Load .env
load_dotenv()
TOKEN = os.getenv("TOKEN")
PREFIX = os.getenv("PREFIX", ".")  # Simple single prefix

# Set up argument parsing
parser = argparse.ArgumentParser(description="Selfbot for Discord")
parser.add_argument("--useragent", type=str, help="Specify the user agent")
parser.add_argument("--loglevel", type=str, choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], help="Set the logging level")
args = parser.parse_args()

# Configure logging level based on argument
if args.loglevel:
    logger.setLevel(args.loglevel)

async def load_cogs(bot, directory="cogs"):
    """Load cogs with duplicate prevention"""
    tasks = []
    extensions = []

    # Get list of already loaded extensions
    already_loaded = list(bot.extensions.keys())
    if already_loaded:
        logger.info(f"Already loaded extensions: {already_loaded}")

    for filename in os.listdir(directory):
        if filename.endswith(".py") and not filename.startswith("_"):
            ext = f"{directory}.{filename[:-3]}"

            # Skip if already loaded
            if ext in already_loaded:
                logger.info(f"Skipping {ext} - already loaded")
                continue

            task = asyncio.create_task(bot.load_extension(ext))
            tasks.append(task)
            extensions.append(ext)
            logger.info(f"Prepared to load {ext}")

    for task, ext in zip(tasks, extensions):
        try:
            await task
            logger.info(f"Successfully loaded {ext}")
        except commands.errors.ExtensionAlreadyLoaded:
            logger.warning(f"{ext} was already loaded, skipping")
        except commands.errors.CommandRegistrationError as e:
            logger.error(f"Command conflict in {ext}: {e}")
            # Try to reload the extension instead
            try:
                await bot.reload_extension(ext)
                logger.info(f"Reloaded {ext} instead")
            except Exception as reload_error:
                logger.error(f"Failed to reload {ext}: {reload_error}")
        except Exception as e:
            logger.error(f"Failed to load {ext}", exc_info=e)

async def unload_all_cogs(bot):
    """Safely unload all cogs"""
    extensions = list(bot.extensions.keys())
    if not extensions:
        logger.info("No cogs to unload")
        return

    logger.info(f"Unloading {len(extensions)} cogs...")
    for ext in extensions:
        try:
            await bot.unload_extension(ext)
            logger.info(f"Unloaded {ext}")
        except Exception as e:
            logger.error(f"Error unloading {ext}: {e}")

class SelfBot(commands.Bot):
    def __init__(self):        
        super().__init__(command_prefix=PREFIX, self_bot=True)
        self.logger = logger
        self.self_bot = True
        self.timeout = 10.0  # Default timeout for commands in seconds
        self.config = {}
        self._ready = asyncio.Event()
        self._processed_messages = set()  # Track processed messages to prevent duplicates

    async def setup_hook(self):
        # Clear any existing cogs first (in case of restart)
        await unload_all_cogs(self)
        # Load cogs fresh
        await load_cogs(self)
        logger.info("Cogs loaded, bot is ready")

    async def on_ready(self):
        if self.user:
            logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        else:
            logger.info("Logged in as unknown user")
        logger.info("------")
        logger.info("------")
        self._ready.set()
        await self.change_presence(afk=True)

    async def on_message(self, message):
        # Only process our own messages
        if message.author != self.user:
            return

        # Prevent processing the same message twice
        if message.id in self._processed_messages:
            return

        self._processed_messages.add(message.id)

        # Clean up old message IDs to prevent memory leak (keep last 100)
        if len(self._processed_messages) > 100:
            self._processed_messages = set(list(self._processed_messages)[-50:])

        # Only process commands once
        await self.process_commands(message)

    # Override process_commands to add protection
    async def process_commands(self, message):
        """Override to prevent duplicate processing"""
        if message.author != self.user:
            return

        # Check if we've already started processing this exact message
        processing_key = f"processing_{message.id}"
        if hasattr(self, '_currently_processing'):
            if processing_key in self._currently_processing:
                return
        else:
            self._currently_processing = set()

        self._currently_processing.add(processing_key)

        try:
            await super().process_commands(message)
        finally:
            # Clean up after processing
            self._currently_processing.discard(processing_key)

    async def on_command(self, ctx):
        """Log when a command is invoked"""
        pass  # Silent - remove debug logging

    async def on_command_completion(self, ctx):
        """Log when a command completes successfully"""
        pass  # Silent - remove debug logging

    async def on_command_error(self, ctx, error):
        """Handle command errors"""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore command not found
        elif isinstance(error, commands.CheckFailure):
            logger.debug(f"Check failed for command {ctx.command}: {error}")
        else:
            logger.error(f"Command {ctx.command} raised an error: {error}", exc_info=error)

    def get_config(self, key, default=None):
        if not hasattr(self, 'config'):
            self.logger.warning(f"Config not available, using default for {key}")
            return default

        config_entry = self.config.get(key, None)
        return default if config_entry is None else config_entry

    async def reload_cog(self, cog_name):
        """Safely reload a specific cog"""
        try:
            await self.reload_extension(f"cogs.{cog_name}")
            logger.info(f"Reloaded cog: {cog_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to reload {cog_name}: {e}")
            return False

async def shutdown_bot():
    if bot:
        logger.info("Shutting down bot...")
        try:
            # Properly unload all cogs
            await unload_all_cogs(bot)
        except Exception as e:
            logger.error("Error unloading cogs during shutdown", exc_info=e)

        logger.info("Closing bot connection...")
        await bot.close()

def handle_exit(sig, frame):
    logger.info(f"Received signal {sig}, shutting down gracefully...")
    loop = asyncio.get_event_loop()
    loop.create_task(shutdown_bot())

async def main():
    global bot
    if not TOKEN:
        raise RuntimeError("TOKEN not found in .env file")

    bot = SelfBot()
    if getattr(args, "useragent", None):
        bot.http.super_properties["browser_user_agent"] = args.useragent   

    async with bot:
        max_retries = 5
        retry_count = 0
        backoff_time = 5

        while retry_count < max_retries:
            try:
                await bot.start(TOKEN)
                break
            except discord.errors.ConnectionClosed as e:
                retry_count += 1
                logger.error(f"Connection closed. Retrying ({retry_count}/{max_retries}) in {backoff_time}s: {e}")
                if retry_count < max_retries:
                    await asyncio.sleep(backoff_time)
                    backoff_time *= 2
                else:
                    logger.critical("Maximum retries reached. Shutting down.")
            except discord.errors.HTTPException as e:
                if hasattr(e, "retry_after"):
                    retry_after = getattr(e, "retry_after", 5)
                    logger.warning(f"Rate limited. Retrying in {retry_after}s")
                    await asyncio.sleep(retry_after)
                else:
                    logger.error(f"HTTP Error: {e}")
                    break
            except Exception as e:
                logger.error("Unexpected exception during bot start", exc_info=e)
                break

if __name__ == "__main__":
    signal.signal(signal.SIGINT, handle_exit)
    signal.signal(signal.SIGTERM, handle_exit)
    asyncio.run(main())