import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import discord
from main import SelfBot, load_cogs

@pytest.fixture
def bot():
    with patch('discord.ext.commands.Bot._get_state'):
        return SelfBot()

@pytest.mark.asyncio
async def test_bot_initialization(bot):
    assert isinstance(bot, discord.ext.commands.Bot)
    assert bot.self_bot == True
    assert hasattr(bot, 'logger')

@pytest.mark.asyncio
async def test_on_message_own_message(bot):
    message = MagicMock()
    message.author = bot.user
    bot.process_commands = AsyncMock()
    
    await bot.on_message(message)
    bot.process_commands.assert_called_once_with(message)

@pytest.mark.asyncio
async def test_on_message_other_user(bot):
    message = MagicMock()
    message.author = MagicMock()
    message.author.id = 123  # Different from bot.user
    bot.process_commands = AsyncMock()
    
    await bot.on_message(message)
    bot.process_commands.assert_not_called()

@pytest.mark.asyncio
async def test_load_cogs():
    mock_bot = AsyncMock()
    mock_bot.load_extension = AsyncMock()
    
    with patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = ['test_cog.py', '_ignored.py', 'not_a_cog.txt']
        await load_cogs(mock_bot, "test_cogs")
        
        mock_bot.load_extension.assert_called_once_with('test_cogs.test_cog')

@pytest.mark.asyncio
async def test_setup_hook(bot):
    with patch('main.load_cogs') as mock_load_cogs:
        await bot.setup_hook()
        mock_load_cogs.assert_called_once_with(bot)