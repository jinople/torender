from discord.ext import commands
import discord
import io

class CustomHelpCommand(commands.HelpCommand):
    def __init__(self):
        super().__init__()

    async def send_bot_help(self, mapping):
        lines = ["Available commands:\n"]

        # Add delete commands section at the top
        lines.extend([
            "=== DELETE COMMANDS ===",
            f"{self.context.clean_prefix}delete [amount]: Delete your recent messages (default: 1)",
            f"{self.context.clean_prefix}delete all: Delete ALL your messages in current channel",
            f"{self.context.clean_prefix}delete multi [amount]: Delete messages across multiple channels",
            f"{self.context.clean_prefix}delete multi all: Delete ALL messages across ALL channels",
            f"{self.context.clean_prefix}delete stop: Stop any ongoing delete operation",
            "",
            "=== SNIPER COMMANDS ===",
            f"{self.context.clean_prefix}snipe [index]: Retrieve deleted messages (up to 10)",
            f"{self.context.clean_prefix}editsnipe: Show recently edited messages",
            f"{self.context.clean_prefix}ghostping: Detect ghost pings in channel",
            "",
            "=== MESSAGE EFFECTS ===",
            f"{self.context.clean_prefix}rainbow <text>: Animated rainbow text effect",
            f"{self.context.clean_prefix}typewriter <text>: Typewriter animation effect",
            f"{self.context.clean_prefix}glitch <text>: Glitched/zalgo text effect",
            f"{self.context.clean_prefix}mock <text>: MoCkInG SpOnGeBoB text",
            f"{self.context.clean_prefix}uwu <text>: UwUify your text",
            f"{self.context.clean_prefix}clap <text>: Add 👏 between 👏 words",
            f"{self.context.clean_prefix}reverse <text>: Reverse text completely",
            f"{self.context.clean_prefix}spacer <text>: S p a c e  o u t  text",
            "",
            "=== AUTOMATION ===",
            f"{self.context.clean_prefix}autoreact @user <emojis>: Auto-react to user's messages",
            f"{self.context.clean_prefix}afkmode [message]: Toggle AFK mode with custom message",
            f"{self.context.clean_prefix}schedule <seconds> <message>: Schedule delayed message",
            "",
            "=== UTILITY COMMANDS ===",
            f"{self.context.clean_prefix}stats [@user]: Show detailed user statistics",
            f"{self.context.clean_prefix}analyze: Deep analysis of current server",
            f"{self.context.clean_prefix}cmdstats: Show command usage statistics",
            f"{self.context.clean_prefix}backup [limit]: Backup channel messages to JSON",
            f"{self.context.clean_prefix}smartpurge <amount> [filter]: Smart purge (filters: me/bots/images/links)",
            f"{self.context.clean_prefix}encode <message>: Encode message in base64",
            f"{self.context.clean_prefix}decode <encoded>: Decode base64 message",
            f"{self.context.clean_prefix}ascii <text>: Convert text to ASCII art",
            "",
            "=== FUN & GAMES ===",
            f"{self.context.clean_prefix}progress <seconds> [label]: Animated in-place progress bar",
            f"{self.context.clean_prefix}poll <seconds> Question | opt1 | opt2 ...: Create a poll with numeric reactions",
            f"{self.context.clean_prefix}trivia: Quick trivia question (first correct wins)",
            f"{self.context.clean_prefix}fortune: Get a random fortune/compliment",
            f"{self.context.clean_prefix}grep <limit> <term>: Search recent messages for a term",
            f"{self.context.clean_prefix}karaoke <speed> <lyrics...>: Karaoke/typewriter-style lyrics display",
            f"{self.context.clean_prefix}meme Top | Bottom (attach image): Create a meme (Pillow required)",
            f"{self.context.clean_prefix}img2ascii <width> (attach image): Convert image to ASCII art (Pillow required)",
            f"{self.context.clean_prefix}ttt start @opponent | move <pos> | resign: Tic-Tac-Toe",
            f"{self.context.clean_prefix}hangman start | guess <letter> | stop: Hangman game",
            "",
            "=== OTHER COMMANDS ===",
            ""
        ])

        for cog, cmds in mapping.items():
            filtered = [c for c in cmds if not c.hidden]
            if not filtered:
                continue

            # Skip UltimateFlex and UserManagementCommands as we've already listed them above
            if cog and cog.qualified_name in ['UltimateFlex', 'UserManagementCommands']:
                continue

            category = f"{getattr(cog, 'qualified_name', 'No Category')}" if cog else "No Category"
            cmd_list = [f"{self.context.clean_prefix}{c.qualified_name}: {c.short_doc or ''}" for c in filtered]
            if cmd_list:
                lines.append(category)
                lines.extend(cmd_list)
                lines.append("")

        help_text = "\n".join(lines)
        file = discord.File(io.StringIO(help_text), filename="help.txt")
        await self.get_destination().send("Information attached.", file=file)

    async def send_cog_help(self, cog):
        lines = [
            f"**{cog.qualified_name or 'No Category'}**",
            cog.description or "",
            ""
        ]

        # Special handling for UserManagementCommands cog
        if cog.qualified_name == "UserManagementCommands":
            lines.extend([
                "**DELETE COMMANDS:**",
                f"`{self.context.clean_prefix}delete [amount]`: Delete your recent messages",
                f"`{self.context.clean_prefix}delete all`: Delete ALL your messages in this channel",
                f"`{self.context.clean_prefix}delete multi [amount]`: Delete messages across all server channels",
                f"`{self.context.clean_prefix}delete multi all`: Delete ALL messages across ALL server channels",
                f"`{self.context.clean_prefix}delete stop`: Stop any ongoing delete operation",
                "",
                "**OTHER USER MANAGEMENT COMMANDS:**"
            ])

        # Special handling for UltimateFlex cog
        elif cog.qualified_name == "UltimateFlex":
            lines.extend([
                "**🎯 SNIPER SUITE:**",
                f"`{self.context.clean_prefix}snipe [index]`: Retrieve up to 10 deleted messages",
                f"`{self.context.clean_prefix}editsnipe`: View edited messages (alias: esnipe)",
                f"`{self.context.clean_prefix}ghostping`: Detect ghost pings (alias: gp)",
                "",
                "**✨ MESSAGE EFFECTS:**",
                f"`{self.context.clean_prefix}rainbow <text>`: Animated rainbow text",
                f"`{self.context.clean_prefix}typewriter <text>`: Typing animation (alias: tw)",
                f"`{self.context.clean_prefix}glitch <text>`: Zalgo/corrupted text",
                f"`{self.context.clean_prefix}mock <text>`: SpOnGeBoB mocking text",
                f"`{self.context.clean_prefix}uwu <text>`: UwUify any message",
                f"`{self.context.clean_prefix}clap <text>`: Add clap emojis between words",
                f"`{self.context.clean_prefix}reverse <text>`: Reverse text",
                f"`{self.context.clean_prefix}spacer <text>`: Space out letters",
                f"`{self.context.clean_prefix}ascii <text>`: ASCII art text",
                "",
                "**🤖 AUTOMATION:**",
                f"`{self.context.clean_prefix}autoreact @user <emojis>`: Auto-react to user",
                f"`{self.context.clean_prefix}afkmode [message]`: Toggle AFK mode (alias: afkm)",
                f"`{self.context.clean_prefix}schedule <seconds> <message>`: Delayed message",
                "",
                "**📊 ANALYTICS:**",
                f"`{self.context.clean_prefix}stats [@user]`: User statistics",
                f"`{self.context.clean_prefix}analyze`: Server analysis",
                f"`{self.context.clean_prefix}cmdstats`: Command usage stats",
                "",
                "**🛠️ UTILITIES:**",
                f"`{self.context.clean_prefix}backup [limit]`: Export channel to JSON",
                f"`{self.context.clean_prefix}smartpurge <amount> [filter]`: Smart message purge (alias: sp)",
                f"`{self.context.clean_prefix}encode <message>`: Base64 encode",
                f"`{self.context.clean_prefix}decode <encoded>`: Base64 decode",
                "",
                "**🎉 FUN & GAMES:**",
                f"`{self.context.clean_prefix}progress <seconds> [label]`: Animated progress bar that edits in-place",
                f"`{self.context.clean_prefix}poll <seconds> Question | opt1 | opt2`: Create a poll (numeric reactions)",
                f"`{self.context.clean_prefix}trivia`: Quick trivia (first correct answer wins)",
                f"`{self.context.clean_prefix}fortune`: Random fortune/compliment",
                f"`{self.context.clean_prefix}grep <limit> <term>`: Search recent messages",
                f"`{self.context.clean_prefix}karaoke <speed> <lyrics>`: Karaoke/typewriter lyrics",
                f"`{self.context.clean_prefix}ttt start @opponent | move <pos> | resign`: Tic-Tac-Toe",
                f"`{self.context.clean_prefix}hangman start | guess <letter> | stop`: Hangman",
                "",
                "**🖼️ IMAGE TOOLS:**",
                f"`{self.context.clean_prefix}meme Top | Bottom`: Create a meme from attached image (Pillow required)",
                f"`{self.context.clean_prefix}img2ascii <width>`: Convert attached image to ASCII (Pillow required)"
            ])
        else:
            # Default handling for other cogs
            for command in cog.get_commands():
                if not command.hidden:
                    # Skip delete commands if we already listed them above
                    if cog.qualified_name == "UserManagementCommands" and command.name.startswith("delete"):
                        continue
                    lines.append(f"`{self.context.clean_prefix}{command.qualified_name}`: {command.short_doc or ''}")

        await self.get_destination().send("\n".join(lines))

    async def send_command_help(self, command):
        lines = [
            f"**Help for `{self.context.clean_prefix}{command.qualified_name}`**",
            f"{command.help or command.short_doc or ''}"
        ]

        # Add detailed help for UltimateFlex commands (including new features)
        if command.cog and command.cog.qualified_name == "UltimateFlex":
            detailed_help = {
                'snipe': "Retrieve deleted messages from the channel.\nUsage: `.snipe [index]`\nIndex 1 = most recent, up to 10 messages stored",
                'editsnipe': "Show the most recently edited message.\nAlias: `.esnipe`",
                'ghostping': "Detect ghost pings (deleted mentions).\nAlias: `.gp`",
                'rainbow': "Create animated rainbow text effect.\nUsage: `.rainbow <your text here>`",
                'typewriter': "Simulate typewriter effect.\nUsage: `.typewriter <text>` or `.tw <text>`",
                'glitch': "Create glitched/zalgo text.\nUsage: `.glitch <text>`",
                'mock': "MoCkInG tExT like SpongeBob.\nUsage: `.mock <text>`",
                'uwu': "UwUify your text.\nUsage: `.uwu <text>`",
                'autoreact': "Auto-react to a user's messages.\nUsage: `.autoreact @user 😎 🔥 💯`\nUse without emojis to disable",
                'afkmode': "Toggle AFK mode with optional message.\nUsage: `.afkmode [custom message]`\nAlias: `.afkm`",
                'schedule': "Schedule a delayed message.\nUsage: `.schedule <seconds> <message>`",
                'stats': "Show detailed user statistics.\nUsage: `.stats [@user]`",
                'analyze': "Deep analysis of current server.\nShows members, channels, activity, roles, and more",
                'cmdstats': "Display your command usage statistics",
                'backup': "Backup channel messages to JSON file.\nUsage: `.backup [limit]` (default: 100)",
                'smartpurge': "Smart purge with filters.\nUsage: `.smartpurge <amount> [filter]`\nFilters: me, bots, images, links\nAlias: `.sp`",
                'encode': "Encode message in base64.\nUsage: `.encode <message>`",
                'decode': "Decode base64 message.\nUsage: `.decode <encoded_string>`",
                'clap': "Add 👏 between 👏 words.\nUsage: `.clap <text>`",
                'reverse': "Reverse text completely.\nUsage: `.reverse <text>`",
                'spacer': "S p a c e  o u t  text.\nUsage: `.spacer <text>`",
                'ascii': "Convert text to ASCII art.\nUsage: `.ascii <text>`",
                # New commands
                'progress': "Show an animated progress bar that edits the invoking message.\nUsage: `.progress <seconds> [label]`",
                'poll': "Create a poll and add numeric reactions for voting.\nUsage: `.poll <seconds> Question | option1 | option2 ...`",
                'trivia': "Ask a trivia question; first correct answer wins.\nUsage: `.trivia`",
                'fortune': "Get a random fortune/compliment.\nUsage: `.fortune`",
                'grep': "Search recent messages for a term and show top results.\nUsage: `.grep <limit> <term>`",
                'karaoke': "Type out lyrics line-by-line with a karaoke/typewriter effect.\nUsage: `.karaoke <speed> <lyrics>`",
                'meme': "Create a meme by adding top|bottom text to an attached image (Pillow required).\nUsage: Attach an image and run `.meme Top text | Bottom text`",
                'img2ascii': "Convert an attached image to ASCII art (Pillow required).\nUsage: Attach an image and run `.img2ascii <width>`",
                'ttt': "Play Tic-Tac-Toe in-channel.\nUsage: `.ttt start @opponent`, `.ttt move <1-9>`, `.ttt resign`",
                'hangman': "Play Hangman.\nUsage: `.hangman start`, `.hangman guess <letter>`, `.hangman stop`",
            }

            if command.name in detailed_help:
                lines = [
                    f"**Help for `{self.context.clean_prefix}{command.qualified_name}`**",
                    detailed_help[command.name]
                ]

        if command.usage and command.name not in ['snipe', 'editsnipe', 'ghostping']:
            lines.append(f"**Usage:** `{self.context.clean_prefix}{command.qualified_name} {command.usage}`")

        await self.get_destination().send("\n".join(lines))

    async def send_group_help(self, group):
        lines = [
            f"**Group `{self.context.clean_prefix}{group.qualified_name}`:** {group.short_doc or ''}",
        ]
        for c in group.commands:
            if not c.hidden:
                lines.append(f"`{self.context.clean_prefix}{c.qualified_name}`: {c.short_doc or ''}")
        await self.get_destination().send("\n".join(lines))

class HelpCog(commands.Cog):
    """Displays help information for all commands including UltimateFlex features."""

    def __init__(self, bot):
        self.bot = bot
        self._old_help_command = bot.help_command
        bot.help_command = CustomHelpCommand()
        bot.help_command.cog = self

    def cog_unload(self):
        self.bot.help_command = self._old_help_command

async def setup(bot):
    await bot.add_cog(HelpCog(bot))