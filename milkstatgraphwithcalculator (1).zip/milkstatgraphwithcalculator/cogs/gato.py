import discord
from discord.ext import commands
import aiohttp

class GatoCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.gconf = self.bot.get_config

    @commands.command("gato", aliases=["cat", "car"])
    async def gato_cmd(self, ctx):
        """send gato cat"""
        url = self.gconf("gato_api_url", "https://api.thecatapi.com/v1/images/search")
        fallback_url = self.gconf("gato_fallback_url", "https://http.cat/404")
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url) as response:
                    if response.status == 200:
                        try:
                            data = await response.json()
                            if data and len(data) > 0 and data[0].get("url"):
                                image_url = data[0].get("url")
                                await self.bot.respond(ctx, image_url)
                            else:
                                await self.bot.respond(ctx, "No image found in API response.")
                        except Exception as e:
                            self.bot.logger.error(f"Error decoding JSON response: {e}")
                            await self.bot.respond(ctx, "Failed to decode JSON response.")
                    else:
                        await self.bot.respond(ctx, fallback_url + "\nFailed to fetch gato image.")
            except Exception as e:
                self.bot.logger.error(f"Error connecting to cat API: {e}")
                await self.bot.respond(ctx, fallback_url + "\nError connecting to cat API.")
    
    @commands.command("doggo", aliases=["dog", "woof"])
    async def doggo_cmd(self, ctx):
        """send a picture of a dog"""
        url = self.gconf("doggo_api_url", "https://dog.ceo/api/breeds/image/random")
        fallback_url = self.gconf("doggo_fallback_url", "https://http.dog/404.jpg")

        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url) as response:
                    if response.status == 200:
                        try:
                            data = await response.json()
                            image_url = data.get("message")
                            if image_url:
                                await self.bot.respond(ctx, image_url)
                            else:
                                await self.bot.respond(ctx, "No image found in API response.")
                        except Exception as e:
                            self.bot.logger.error(f"Error decoding JSON response: {e}")
                            await self.bot.respond(ctx, "Failed to decode JSON response.")
                    else:
                        await self.bot.respond(ctx, fallback_url + "\nFailed to fetch doggo image.")
            except Exception as e:
                self.bot.logger.error(f"Error connecting to doggo API: {e}")
                await self.bot.respond(ctx, fallback_url + "\nError connecting to doggo API.")

    @commands.command("gato_agua")
    async def cmd_horse(self, ctx):
        """send gato agua (water cat)"""
        await self.bot.respond(ctx, "https://media.discordapp.net/attachments/561732072868282378/1155445321497841714/gato_agua.gif")

async def setup(bot):
    await bot.add_cog(GatoCog(bot))
