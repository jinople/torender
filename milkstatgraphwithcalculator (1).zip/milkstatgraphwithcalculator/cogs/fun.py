import discord
from discord.ext import commands
import aiohttp
from bs4 import BeautifulSoup
import ssl
import asyncio
import time
from collections import defaultdict, deque

ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

class FunCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.gconf = self.bot.config.get  # Fix the config method
        self.bot.horsin = []
        self.bot.reactions = {}
        
        # Rate limiting for reactions
        self.reaction_queue = asyncio.Queue()
        self.reaction_timestamps = deque(maxlen=300)  # Track last 300 reactions
        self.last_reaction_time = 0
        self.reaction_processor_running = False
        
        # Start the reaction processor
        self.bot.loop.create_task(self.process_reaction_queue())

    async def can_add_reaction(self):
        """Check if we can add a reaction without hitting rate limits"""
        now = time.time()
        
        # Remove timestamps older than 10 minutes (600 seconds)
        while self.reaction_timestamps and now - self.reaction_timestamps[0] > 600:
            self.reaction_timestamps.popleft()
        
        # Check if we've hit the 300 reactions per 10 minutes limit
        if len(self.reaction_timestamps) >= 300:
            return False
        
        # Check if we need to wait for the 0.25 second cooldown
        time_since_last = now - self.last_reaction_time
        if time_since_last < 0.25:
            return False
            
        return True

    async def process_reaction_queue(self):
        """Process reactions from the queue with proper rate limiting"""
        self.reaction_processor_running = True
        
        while True:
            try:
                # Get the next reaction from the queue
                message, emoji = await self.reaction_queue.get()
                
                # Wait until we can safely add a reaction
                while not await self.can_add_reaction():
                    await asyncio.sleep(0.1)  # Check every 100ms
                
                # Add the reaction
                try:
                    await message.add_reaction(emoji)
                    self.last_reaction_time = time.time()
                    self.reaction_timestamps.append(self.last_reaction_time)
                    
                except discord.HTTPException as e:
                    if e.status == 429:  # Rate limited
                        print(f"Rate limited on reaction, waiting...")
                        # Wait for the retry-after time if provided
                        retry_after = getattr(e, 'retry_after', 1)
                        await asyncio.sleep(retry_after)
                        # Put the reaction back in the queue to try again
                        await self.reaction_queue.put((message, emoji))
                    else:
                        print(f"Failed to add reaction: {e}")
                        
                except Exception as e:
                    print(f"Unexpected error adding reaction: {e}")
                
                # Mark this task as done
                self.reaction_queue.task_done()
                
            except Exception as e:
                print(f"Error in reaction processor: {e}")
                await asyncio.sleep(1)  # Wait a bit before continuing

    async def queue_reaction(self, message, emoji):
        """Add a reaction to the queue for processing"""
        try:
            # Don't queue if the queue is getting too full (prevents memory issues)
            if self.reaction_queue.qsize() < 100:
                await self.reaction_queue.put((message, emoji))
            else:
                print("Reaction queue full, skipping reaction")
        except Exception as e:
            print(f"Failed to queue reaction: {e}")

    @commands.command("httpcat", aliases=["hcat", "code", "http"])
    async def hcat_cmd(self, ctx, code: int):
        cat_url = f"https://http.cat/{code}"
        doc_url = f"https://httpstatuses.com/{code}"

        async with aiohttp.ClientSession() as session:
            async with session.get(doc_url) as resp:
                if resp.status != 200:
                    await self.bot.respond(ctx, f"{cat_url}\nNo docs found for code {code}.")
                    return

                html = await resp.text()
                soup = BeautifulSoup(html, "html.parser")
                section = soup.find("section")
                if section:
                    desc = section.find("p").text.strip()
                else:
                    desc = "No description found."

        await self.bot.respond(ctx, f"{cat_url}\n**{code}**: {desc}")

    @commands.command("horse")
    async def cmd_horse(self, ctx):
        """Toggle horse reactions in a channel"""
        if ctx.channel.id in self.bot.horsin:
            self.bot.horsin.remove(ctx.channel.id)
            await self.bot.respond(ctx, "no longer horsin around D:")
        else:
            self.bot.horsin.append(ctx.channel.id)
            await ctx.reply(":D")

    @commands.Cog.listener()
    async def on_message(self, message):
        # Ignore messages from bots
        if message.author.bot:
            return

        reactions_to_add = []

        # Check for horse reactions
        if message.channel.id in self.bot.horsin or self.gconf("fun_auto_horse_enabled", False):
            horse_emoji = self.gconf("fun_horse_reaction", "🐴")
            if horse_emoji:
                reactions_to_add.append(horse_emoji)

        # Check for custom channel reactions
        emoji = self.bot.reactions.get(message.channel.id)
        if emoji:
            reactions_to_add.append(emoji)

        # Queue all reactions for processing
        for emoji in reactions_to_add:
            await self.queue_reaction(message, emoji)

    @commands.command("react")
    async def cmd_react(self, ctx):
        """
        Set a custom emoji to auto-react with in this channel.
        Use `.react off` to disable.
        """
        message = ctx.message
        parts = message.content.strip().split(maxsplit=1)
        if len(parts) < 2:
            await message.reply("Usage: `.react <emoji>` or `.react off`")
            return

        arg = parts[1].strip()

        if arg.lower() == "off":
            self.bot.reactions.pop(message.channel.id, None)
            await message.reply("No longer auto-reacting in this channel.")
        else:
            self.bot.reactions[message.channel.id] = arg
            await message.reply(f"Will now react with {arg} in this channel. Use .react off to disable.")

    @commands.command()
    async def edited(self, ctx, *, msg: str):
        count = msg.count('(edited)')
        if count != 1:
            await self.bot.respond(ctx, "Message must contain **exactly one** instance of `(edited)`.")
            return

        # Use RTL character to make it render oddly
        rtl = '\u202B'
        new_msg = msg.replace('(edited)', rtl)

        try:
            await ctx.message.edit(content=new_msg)
        except Exception as e:
            await self.bot.respond(ctx, f"Failed to edit message: {e}")

    @commands.command("queue_status")
    async def queue_status(self, ctx):
        """Show reaction queue status"""
        queue_size = self.reaction_queue.qsize()
        recent_reactions = len(self.reaction_timestamps)
        
        status_msg = f"**Reaction Queue Status:**\n"
        status_msg += f"Queue size: {queue_size}\n"
        status_msg += f"Reactions in last 10min: {recent_reactions}/300\n"
        status_msg += f"Processor running: {self.reaction_processor_running}"
        
        await self.bot.respond(ctx, status_msg)

    def cog_unload(self):
        """Clean up when the cog is unloaded"""
        self.reaction_processor_running = False

async def setup(bot):
    await bot.add_cog(FunCog(bot))