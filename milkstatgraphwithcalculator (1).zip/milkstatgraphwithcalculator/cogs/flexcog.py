import discord
from discord.ext import commands, tasks
import asyncio
import aiohttp
import json
import random
import re
import base64
from datetime import datetime, timedelta
from collections import defaultdict, deque
from typing import Optional, Dict, List
import io

# Optional image features
try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False

NUMBER_EMOJIS = ["0️⃣", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]

class UltimateFlex(commands.Cog):
    """🔥 The Ultimate Self-Bot Cog - Prepare to be amazed! 🔥"""

    def __init__(self, bot):
        self.bot = bot
        self.session = None

        # Sniper data
        self.deleted_messages = defaultdict(lambda: deque(maxlen=10))
        self.edited_messages = defaultdict(lambda: deque(maxlen=10))
        self.ghost_pings = defaultdict(list)

        # Auto-react system
        self.auto_react_users = {}  # user_id: [emojis]
        self.reaction_triggers = {}  # word: emoji

        # Message effects
        self.rainbow_mode = False
        self.typing_effect = False
        self.glitch_mode = False

        # Stats tracking
        self.message_stats = defaultdict(int)
        self.command_usage = defaultdict(int)
        self.last_seen = {}

        # Advanced features
        self.afk_mode = {'enabled': False, 'message': None, 'mentions': []}
        self.message_scheduler = {}
        self.encrypted_channels = set()

        # Game states
        self.trivia_questions = [
            {"q": "What is the capital of France?", "a": "paris"},
            {"q": "2 + 2 * 2 = ?", "a": "6"},
            {"q": "Which planet is known as the Red Planet?", "a": "mars"},
        ]
        self.trivia_scores = defaultdict(int)
        self.active_trivia = {}

        self.active_polls = {}
        self.ttt_games = {}
        self.hangman_games = {}

        self.fortunes = [
            "You will find something you thought was lost.",
            "A surprise meeting will brighten your day.",
            "Expect a call from an old friend.",
            "Today is a good day to try something new.",
            "You will make someone smile today."
        ]

    async def cog_load(self):
        """Initialize the cog"""
        self.session = aiohttp.ClientSession()
        self.status_cycler.start()
        self.stats_updater.start()
        print("⚡ UltimateFlex Cog Loaded - Time to flex! 💪")

    async def cog_unload(self):
        """Cleanup"""
        self.status_cycler.cancel()
        self.stats_updater.cancel()
        if self.session:
            await self.session.close()

    # ============ SNIPER FEATURES ============

    @commands.command(name='snipe')
    async def snipe(self, ctx, index: int = 1):
        """Snipe deleted messages (up to 10 recent)"""
        self.command_usage['snipe'] += 1

        if ctx.channel.id not in self.deleted_messages or not self.deleted_messages[ctx.channel.id]:
            await ctx.message.edit(content="❌ No deleted messages to snipe!")
            return

        try:
            msg_data = list(self.deleted_messages[ctx.channel.id])[-(index)]
            # Format as text instead of embed
            snipe_text = f"**Sniped:** {msg_data['author']}\n{msg_data['content']}\n*Deleted {msg_data['deleted_at'].strftime('%H:%M:%S')}* [{index}/{len(self.deleted_messages[ctx.channel.id])}]"
            await ctx.message.edit(content=snipe_text)
        except IndexError:
            await ctx.message.edit(content=f"❌ Only {len(self.deleted_messages[ctx.channel.id])} messages available!")

    @commands.command(name='editsnipe', aliases=['esnipe'])
    async def edit_snipe(self, ctx):
        """Snipe edited messages"""
        self.command_usage['editsnipe'] += 1

        if ctx.channel.id not in self.edited_messages or not self.edited_messages[ctx.channel.id]:
            await ctx.message.edit(content="❌ No edited messages to snipe!")
            return

        msg_data = self.edited_messages[ctx.channel.id][-1]
        edit_text = f"**✏️ Edit Sniped - {msg_data['author']}**\n**Before:** {msg_data['before'][:500]}\n**After:** {msg_data['after'][:500]}\n*{msg_data['edited_at'].strftime('%H:%M:%S')}*"
        await ctx.message.edit(content=edit_text)

    @commands.command(name='ghostping', aliases=['gp'])
    async def ghost_ping_detector(self, ctx):
        """Show recent ghost pings"""
        self.command_usage['ghostping'] += 1

        if ctx.channel.id not in self.ghost_pings or not self.ghost_pings[ctx.channel.id]:
            await ctx.message.edit(content="👻 No ghost pings detected!")
            return

        pings_text = "**👻 Ghost Pings Detected!**\n"
        for ping in self.ghost_pings[ctx.channel.id][-5:]:
            pings_text += f"• {ping['author']} at {ping['time'].strftime('%H:%M:%S')}: {ping['content'][:100]}\n"
        await ctx.message.edit(content=pings_text)

    # ============ MESSAGE EFFECTS ============

    @commands.command(name='rainbow')
    async def rainbow_text(self, ctx, *, text: str):
        """Send text with rainbow effect (edits through colors)"""
        self.command_usage['rainbow'] += 1

        colors = ['❤️', '🧡', '💛', '💚', '💙', '💜']

        for _ in range(2):
            for color in colors:
                await ctx.message.edit(content=f"{color} {text} {color}")
                await asyncio.sleep(0.5)
        await ctx.message.edit(content=f"🌈 {text} 🌈")

    @commands.command(name='typewriter', aliases=['tw'])
    async def typewriter_effect(self, ctx, *, text: str):
        """Send message with typewriter effect"""
        self.command_usage['typewriter'] += 1

        typed = ""
        for char in text:
            typed += char
            await ctx.message.edit(content=typed + '▌')
            await asyncio.sleep(random.uniform(0.05, 0.15))

        await ctx.message.edit(content=typed)

    @commands.command(name='glitch')
    async def glitch_text(self, ctx, *, text: str):
        """Create glitched/zalgo text effect"""
        self.command_usage['glitch'] += 1

        glitch_chars = ['̸', '̷', '̶', '̴', '̵', '̡', '̢', '̧', '̨', '̛', '̖', '̗', '̘', '̙', '̜', '̝', '̞', '̟', '̠']
        glitched = ''.join(char + random.choice(glitch_chars) * random.randint(1, 3) for char in text)
        await ctx.message.edit(content=glitched)

    @commands.command(name='ascii')
    async def ascii_art(self, ctx, *, text: str):
        """Convert text to ASCII art"""
        self.command_usage['ascii'] += 1

        # Simple ASCII art converter
        ascii_letters = {
            'A': '  ▄▄▄   \n ▐█▀█▌  \n▐█▄▄█▌  ',
            'B': '██████╗ \n██╔══██╗\n██████╔╝',
            'H': '██   ██ \n██   ██ \n███████ ',
            'I': '  ██  \n  ██  \n  ██  ',
        }

        result = text.upper()
        for letter in result:
            if letter in ascii_letters:
                await ctx.message.edit(content=f"```\n{ascii_letters[letter]}\n```")
                return

        # Fallback
        await ctx.message.edit(content=f"```\n{text}\n```")

    # ============ AUTO FEATURES ============

    @commands.command(name='autoreact')
    async def auto_react(self, ctx, user: discord.User, *emojis):
        """Auto-react to specific user's messages"""
        self.command_usage['autoreact'] += 1

        if not emojis:
            if user.id in self.auto_react_users:
                del self.auto_react_users[user.id]
                await ctx.message.edit(content=f"✅ Stopped auto-reacting to {user.mention}")
            else:
                await ctx.message.edit(content="❌ Provide emojis to react with!")
        else:
            self.auto_react_users[user.id] = list(emojis)[:5]
            await ctx.message.edit(content=f"✅ Auto-reacting to {user.mention} with {' '.join(emojis[:5])}")

    @commands.command(name='afk2', aliases=['afkmode'])
    async def afk_mode(self, ctx, *, message: str = None):
        """Enable AFK mode with custom message"""
        self.command_usage['afk2'] += 1

        self.afk_mode['enabled'] = not self.afk_mode['enabled']

        if self.afk_mode['enabled']:
            self.afk_mode['message'] = message or "I'm currently AFK!"
            self.afk_mode['mentions'] = []
            await ctx.message.edit(content=f"😴 AFK Mode **enabled**: {self.afk_mode['message']}")
        else:
            mentions = len(self.afk_mode['mentions'])
            await ctx.message.edit(content=f"👋 Welcome back! You had {mentions} mentions while away.")
            self.afk_mode['mentions'] = []

    # ============ UTILITY COMMANDS ============

    @commands.command(name='stats')
    async def user_stats(self, ctx, user: Optional[discord.User] = None):
        """Show detailed user statistics"""
        self.command_usage['stats'] += 1

        user = user or ctx.author

        # Calculate stats
        mutual_guilds = sum(1 for guild in self.bot.guilds if user in guild.members)
        total_messages = self.message_stats.get(user.id, 0)
        last_seen_time = self.last_seen.get(user.id, "Never")

        stats_text = f"""**📊 Stats for {user}**
**Account Created:** <t:{int(user.created_at.timestamp())}:R>
**User ID:** `{user.id}`
**Mutual Servers:** {mutual_guilds}
**Messages Tracked:** {total_messages}
**Last Seen:** {last_seen_time}
**Bot?** {'✅' if user.bot else '❌'}"""

        await ctx.message.edit(content=stats_text)

    @commands.command(name='encode')
    async def encode_message(self, ctx, *, message: str):
        """Encode message in base64"""
        self.command_usage['encode'] += 1

        encoded = base64.b64encode(message.encode()).decode()
        await ctx.message.edit(content=f"🔐 `{encoded}`")

    @commands.command(name='decode')
    async def decode_message(self, ctx, *, encoded: str):
        """Decode base64 message"""
        self.command_usage['decode'] += 1

        try:
            decoded = base64.b64decode(encoded.encode()).decode()
            await ctx.message.edit(content=f"🔓 {decoded}")
        except:
            await ctx.message.edit(content="❌ Invalid base64 string!")

    @commands.command(name='schedule')
    async def schedule_message(self, ctx, delay: int, *, message: str):
        """Schedule a message (delay in seconds)"""
        self.command_usage['schedule'] += 1

        await ctx.message.edit(content=f"⏰ Scheduled in {delay}s...")
        await asyncio.sleep(delay)
        await ctx.message.edit(content=message)

    # ============ FUN COMMANDS ============

    @commands.command(name='mock')
    async def mock_text(self, ctx, *, text: str):
        """MoCk TeXt LiKe SpOnGeBoB"""
        self.command_usage['mock'] += 1

        mocked = ''.join(char.upper() if i % 2 else char.lower() for i, char in enumerate(text))
        await ctx.message.edit(content=mocked)

    @commands.command(name='reverse')
    async def reverse_text(self, ctx, *, text: str):
        """Reverse text completely"""
        self.command_usage['reverse'] += 1

        await ctx.message.edit(content=text[::-1])

    @commands.command(name='clap')
    async def clap_text(self, ctx, *, text: str):
        """Add 👏 clap 👏 emojis 👏 between 👏 words"""
        self.command_usage['clap'] += 1

        clapped = ' 👏 '.join(text.split())
        await ctx.message.edit(content=f"👏 {clapped} 👏")

    @commands.command(name='uwu')
    async def uwuify(self, ctx, *, text: str):
        """UwUify text"""
        self.command_usage['uwu'] += 1

        uwu_text = text.replace('r', 'w').replace('l', 'w').replace('R', 'W').replace('L', 'W')
        uwu_text = re.sub(r'[nN]([aeiouAEIOU])', r'ny\1', uwu_text)
        uwu_text += ' uwu~'

        await ctx.message.edit(content=uwu_text)

    @commands.command(name='spacer')
    async def space_text(self, ctx, *, text: str):
        """S p a c e  o u t  t e x t"""
        self.command_usage['spacer'] += 1

        spaced = ' '.join(char for char in text if char != ' ')
        await ctx.message.edit(content=spaced)

    # ============ NEW FUN FEATURES ============

    @commands.command(name='progress')
    async def progress(self, ctx, seconds: int = 3, *, label: str = ""):
        """Show an animated progress bar"""
        self.command_usage['progress'] += 1
        label = label or "Progress"

        total_steps = max(6, seconds * 4)
        for i in range(total_steps):
            blocks = int((i + 1) / total_steps * 10)
            bar = "█" * blocks + "░" * (10 - blocks)
            pct = int((i + 1) / total_steps * 100)
            await ctx.message.edit(content=f"{label} [{bar}] {pct}%")
            await asyncio.sleep(max(0.1, seconds / total_steps))
        await ctx.message.edit(content=f"{label} [██████████] 100% ✅")

    @commands.command(name='poll')
    async def poll(self, ctx, timeout: int = 30, *, body: str):
        """Create a poll. Usage: .poll 30 Question | option1 | option2"""
        self.command_usage['poll'] += 1

        parts = [p.strip() for p in body.split("|")]
        if len(parts) < 2:
            await ctx.message.edit(content="Usage: .poll <seconds> Question | option1 | option2 ...")
            return

        question = parts[0]
        options = parts[1:][:10]

        # Build poll text
        lines = [f"📊 **{question}** (ends in {timeout}s)"]
        for i, opt in enumerate(options, start=1):
            emoji = NUMBER_EMOJIS[i]
            lines.append(f"{emoji} {opt}")

        poll_text = "\n".join(lines)
        await ctx.message.edit(content=poll_text)

        # Add reactions
        for i in range(1, len(options) + 1):
            try:
                await ctx.message.add_reaction(NUMBER_EMOJIS[i])
            except:
                pass

        # Store poll and wait
        self.active_polls[ctx.message.id] = {"options": options, "end": datetime.utcnow() + timedelta(seconds=timeout)}
        await asyncio.sleep(timeout)

        # Get results
        try:
            msg = await ctx.channel.fetch_message(ctx.message.id)
            counts = []
            for i in range(1, len(options) + 1):
                cnt = 0
                for r in msg.reactions:
                    if r.emoji == NUMBER_EMOJIS[i]:
                        cnt = r.count - 1  # subtract self
                        break
                counts.append(cnt)

            total = sum(counts)
            result_lines = [f"📊 **Results: {question}**"]
            for i, opt in enumerate(options, start=1):
                pct = (counts[i-1] / total * 100) if total else 0
                result_lines.append(f"{NUMBER_EMOJIS[i]} {opt} — **{counts[i-1]}** ({pct:.0f}%)")

            await ctx.message.edit(content="\n".join(result_lines))
        except:
            await ctx.message.edit(content="Poll ended!")

    @commands.command(name='trivia')
    async def trivia(self, ctx):
        """Ask a trivia question"""
        self.command_usage['trivia'] += 1

        q = random.choice(self.trivia_questions)
        question = q["q"]
        answer = q["a"].lower()

        await ctx.message.edit(content=f"❓ **Trivia:** {question}\nAnswer in chat!")
        self.active_trivia[ctx.channel.id] = {"answer": answer, "asked_by": ctx.author.id}

        def check(m):
            return m.channel.id == ctx.channel.id and m.author != self.bot.user

        try:
            msg = await self.bot.wait_for('message', timeout=20.0, check=check)
            if msg.content.lower().strip() == answer:
                self.trivia_scores[msg.author.id] += 1
                await ctx.message.edit(content=f"✅ {msg.author.mention} got it! **{answer}** (Score: {self.trivia_scores[msg.author.id]})")
            else:
                await ctx.message.edit(content=f"❌ Time's up! Answer was: **{answer}**")
        except asyncio.TimeoutError:
            await ctx.message.edit(content=f"⌛ Time's up! Answer was: **{answer}**")
        finally:
            self.active_trivia.pop(ctx.channel.id, None)

    @commands.command(name='fortune')
    async def fortune(self, ctx):
        """Get a random fortune"""
        self.command_usage['fortune'] += 1
        await ctx.message.edit(content=f"🔮 {random.choice(self.fortunes)}")

    @commands.command(name='grep')
    async def grep(self, ctx, limit: int = 200, *, term: str):
        """Search recent messages for a term"""
        self.command_usage['grep'] += 1

        results = []
        async for msg in ctx.channel.history(limit=limit):
            if term.lower() in (msg.content or "").lower():
                results.append((msg.author, msg.content, msg.created_at))
                if len(results) >= 5:
                    break

        if not results:
            await ctx.message.edit(content=f"No results for '{term}'")
            return

        lines = [f"🔎 **Search results for '{term}':**"]
        for author, content, ts in results:
            snippet = (content[:100] + "...") if len(content) > 100 else content
            lines.append(f"• **{author}**: {snippet}")

        await ctx.message.edit(content="\n".join(lines))

    @commands.command(name='karaoke')
    async def karaoke(self, ctx, speed: float = 0.8, *, lyrics: str):
        """Display lyrics karaoke style"""
        self.command_usage['karaoke'] += 1

        lines = [l for l in lyrics.splitlines() if l.strip()]
        if not lines:
            await ctx.message.edit(content="Provide lyrics!")
            return

        for line in lines:
            await ctx.message.edit(content=f"🎤 {line}")
            await asyncio.sleep(max(0.2, speed))

        await ctx.message.edit(content="🎤 *fin*")

    # ============ GAMES ============

    @commands.command(name='hangman')
    async def hangman(self, ctx, subcmd: str = None, guess: str = None):
        """Play hangman. Usage: .hangman start | guess <letter> | stop"""
        self.command_usage['hangman'] += 1
        ch = ctx.channel.id

        if subcmd == 'start':
            if ch in self.hangman_games:
                await ctx.message.edit(content="Game already running!")
                return

            word = random.choice(["python", "discord", "bot", "ultimate", "flex"])
            game = {"word": word, "guessed": set(), "tries": 6}
            self.hangman_games[ch] = game

            display = " ".join(["_" for _ in word])
            await ctx.message.edit(content=f"**Hangman Started!**\n`{display}`\nTries left: 6")

        elif subcmd == 'guess':
            if ch not in self.hangman_games:
                await ctx.message.edit(content="No game! Start with `.hangman start`")
                return

            if not guess:
                await ctx.message.edit(content="Provide a letter!")
                return

            game = self.hangman_games[ch]
            letter = guess[0].lower()

            if letter in game["guessed"]:
                await ctx.message.edit(content="Already guessed that!")
                return

            game["guessed"].add(letter)

            if letter not in game["word"]:
                game["tries"] -= 1

            display = " ".join([c if c in game["guessed"] else "_" for c in game["word"]])

            if all(c in game["guessed"] for c in game["word"]):
                await ctx.message.edit(content=f"🎉 **You won!** Word: `{game['word']}`")
                del self.hangman_games[ch]
            elif game["tries"] <= 0:
                await ctx.message.edit(content=f"💀 **Game Over!** Word was: `{game['word']}`")
                del self.hangman_games[ch]
            else:
                await ctx.message.edit(content=f"**Hangman**\n`{display}`\nTries: {game['tries']} | Guessed: {', '.join(sorted(game['guessed']))}")

        elif subcmd == 'stop':
            if ch in self.hangman_games:
                word = self.hangman_games[ch]["word"]
                del self.hangman_games[ch]
                await ctx.message.edit(content=f"Game stopped. Word was: `{word}`")
            else:
                await ctx.message.edit(content="No game to stop!")
        else:
            await ctx.message.edit(content="Usage: `.hangman start` | `.hangman guess <letter>` | `.hangman stop`")

    @commands.command(name='cmdstats')
    async def command_stats(self, ctx):
        """Show command usage statistics"""

        if not self.command_usage:
            await ctx.message.edit(content="📊 No commands used yet!")
            return

        sorted_cmds = sorted(self.command_usage.items(), key=lambda x: x[1], reverse=True)[:10]

        stats_text = "**📈 Command Usage Stats**\n"
        for i, (cmd, count) in enumerate(sorted_cmds, 1):
            stats_text += f"{i}. `{cmd}`: **{count}** uses\n"

        total = sum(self.command_usage.values())
        stats_text += f"\n*Total: {total} commands*"

        await ctx.message.edit(content=stats_text)

    @commands.command(name='analyze')
    async def analyze_server(self, ctx):
        """Deep analysis of current server"""
        self.command_usage['analyze'] += 1

        if not ctx.guild:
            await ctx.message.edit(content="❌ Server only command!")
            return

        guild = ctx.guild

        # Gather stats safely
        try:
            members = len(guild.members)
            humans = sum(1 for m in guild.members if not m.bot)
            bots = members - humans
            text_ch = sum(1 for c in guild.channels if isinstance(c, discord.TextChannel))
            voice_ch = sum(1 for c in guild.channels if isinstance(c, discord.VoiceChannel))

            analysis = f"""**🔍 Server Analysis: {guild.name}**
**Owner:** {guild.owner.mention if guild.owner else 'Unknown'}
**Created:** <t:{int(guild.created_at.timestamp())}:R>
**Members:** {members} ({humans} humans, {bots} bots)
**Channels:** {text_ch} text, {voice_ch} voice
**Boosts:** {guild.premium_subscription_count} (Tier {guild.premium_tier})
**Verification:** {str(guild.verification_level).title()}"""

            await ctx.message.edit(content=analysis)
        except Exception as e:
            await ctx.message.edit(content=f"❌ Analysis failed: {str(e)}")

    # ============ LISTENERS ============

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Track deleted messages"""
        if message.author.bot:
            return

        self.deleted_messages[message.channel.id].append({
            'content': message.content or '[Embed/Attachment]',
            'author': str(message.author),
            'avatar': str(message.author.avatar.url) if message.author.avatar else "",
            'deleted_at': datetime.utcnow()
        })

        # Ghost ping detection
        if self.bot.user and self.bot.user in message.mentions:
            self.ghost_pings[message.channel.id].append({
                'author': str(message.author),
                'content': message.content,
                'time': datetime.utcnow()
            })

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Track edited messages"""
        if before.author.bot or before.content == after.content:
            return

        self.edited_messages[before.channel.id].append({
            'before': before.content,
            'after': after.content,
            'author': str(before.author),
            'avatar': str(before.author.avatar.url) if before.author.avatar else "",
            'edited_at': datetime.utcnow()
        })

    @commands.Cog.listener()
    async def on_message(self, message):
        """Track messages and handle auto features"""
        # Skip our own messages
        if message.author == self.bot.user:
            return

        # Update stats
        self.message_stats[message.author.id] += 1
        self.last_seen[message.author.id] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

        # Auto-react to specific users
        if message.author.id in self.auto_react_users:
            for emoji in self.auto_react_users[message.author.id]:
                try:
                    await message.add_reaction(emoji)
                    await asyncio.sleep(0.5)
                except:
                    pass

        # AFK mode handling  
        if self.afk_mode['enabled'] and self.bot.user in message.mentions:
            self.afk_mode['mentions'].append({
                'author': str(message.author),
                'content': message.content,
                'time': datetime.utcnow()
            })
            await message.reply(self.afk_mode['message'], mention_author=False)

    # ============ BACKGROUND TASKS ============

    @tasks.loop(minutes=5)
    async def status_cycler(self):
        """Cycle through statuses"""
        statuses = [
            discord.Game("with code"),
            discord.Activity(type=discord.ActivityType.watching, name="for commands"),
            discord.Activity(type=discord.ActivityType.listening, name="music"),
        ]

        try:
            await self.bot.change_presence(activity=random.choice(statuses))
        except:
            pass

    @tasks.loop(hours=1)
    async def stats_updater(self):
        """Update stats periodically"""
        total_tracked = sum(self.message_stats.values())
        print(f"📊 Stats: {total_tracked} messages from {len(self.message_stats)} users")

    @status_cycler.before_loop
    async def before_status_loop(self):
        await self.bot.wait_until_ready()

    @stats_updater.before_loop
    async def before_stats_loop(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    if 'UltimateFlex' in bot.cogs:
        print("⚠️ UltimateFlex already loaded")
        return

    await bot.add_cog(UltimateFlex(bot))
    print("🚀 UltimateFlex Cog has been added to the bot!")