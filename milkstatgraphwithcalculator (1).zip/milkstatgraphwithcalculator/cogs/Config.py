from discord.ext import commands
import json
import os
import tomlkit
from typing import Any, Callable, Awaitable
from datetime import datetime
import math
ITEMS_PER_PAGE = 5 # should this be a config in of itself? :lenny:


CONFIG_PATH = "config.toml"
OLD_CONFIG_PATH = "config.json"
SPEC_PATH = "config_specification.json"

# Type for hook function
CONFIG_HOOK_TYPE = Callable[[commands.Context, Any, Any], Awaitable[bool]]

# TOML configuration replaces the older JSON format
# The bot will automatically migrate from config.json to config.toml

class ConfigCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Keep any existing config
        if not hasattr(self.bot, 'config'):
            self.bot.config = {}
        self.config_spec = {}
        
        # Initialize config hooks registry
        if not hasattr(self.bot, 'config_hooks'):
            self.bot.config_hooks = {}
            
        # Add the decorator to the bot
        self.bot.config_hook = self.config_hook
        
        # Add helper methods to the bot
        self.bot.register_config_hook = self.register_hook
        self.bot.run_config_hooks = self.run_hooks
        
        self.bot.loop.create_task(self.load_config())
    
    def cog_unload(self):
        """Save config when the cog is unloaded"""
        # Keep config in bot to ensure other cogs can still access it
        self.bot.loop.create_task(self.save_config())

    async def load_config(self):
        try:
            # Load config spec first (still in JSON format)
            if os.path.exists(SPEC_PATH):
                # --- FIX: Explicitly open with UTF-8 encoding ---
                with open(SPEC_PATH, "r", encoding='utf-8') as f:
                    self.config_spec = json.load(f)
                self.bot.logger.info(f"Config specification loaded with {len(self.config_spec)} entries.")
            else:
                self.bot.logger.error("Config specification file not found.")
                return

            # First check for new TOML config
            if os.path.exists(CONFIG_PATH) and os.path.getsize(CONFIG_PATH) > 0:
                self.bot.logger.info(f"Loading TOML config from {CONFIG_PATH}")
                with open(CONFIG_PATH, "r") as f:
                    toml_data = tomlkit.parse(f.read())
                    
                    # Initialize value metadata storage
                    self.bot.config_value_metadata = {}
                    
                    # Check if config uses the new table structure
                    if "settings" in toml_data:
                        self.bot.logger.info("Loading settings from TOML structure")
                        settings_table = toml_data["settings"]
                        self.bot.config = {k: v for k, v in settings_table.items()}
                        
                        # Load value metadata if present
                        if "value_metadata" in toml_data:
                            value_metadata = toml_data["value_metadata"]
                            self.bot.config_value_metadata = {k: dict(v) for k, v in value_metadata.items()}
                            self.bot.logger.info(f"Loaded metadata for {len(self.bot.config_value_metadata)} individual settings")
                        
                        # Load global metadata if present
                        if "metadata" in toml_data:
                            metadata = toml_data["metadata"]
                            # Store metadata in bot for access elsewhere
                            self.bot.config_file_metadata = dict(metadata)
                            self.bot.logger.info(f"Config metadata: last updated {metadata.get('last_updated', 'unknown')}, version {metadata.get('version', 'unknown')}")
                    else:
                        # Legacy format (flat structure)
                        self.bot.logger.info("Loading legacy flat TOML structure")
                        self.bot.config = {k: v for k, v in toml_data.items() if not k.startswith("__") and k != "metadata" and k != "value_metadata"}
                        
                    self.bot.logger.info(f"TOML config loaded with {len(self.bot.config)} entries.")
            # If TOML config doesn't exist or is empty, check for old JSON config
            elif os.path.exists(OLD_CONFIG_PATH):
                self.bot.logger.info(f"Found old JSON config at {OLD_CONFIG_PATH}, migrating to TOML...")
                # --- FIX: Explicitly open with UTF-8 encoding for old JSON config ---
                with open(OLD_CONFIG_PATH, "r", encoding='utf-8') as f:
                    self.bot.config = json.load(f)
                self.bot.logger.info(f"Loaded JSON config with {len(self.bot.config)} entries")
                # Initialize value metadata for the migration
                self.bot.config_value_metadata = {}
                for key in self.bot.config.keys():
                    self.bot.config_value_metadata[key] = {
                        "last_updated": "migrated from JSON",
                        "updated_by": "migration"
                    }
                # Save in TOML format
                await self.save_config(["Migration from JSON"])
                self.bot.logger.info("Successfully migrated from JSON to TOML.")
            else:
                self.bot.logger.warning("No config files found. Using defaults.")
                self.bot.config = {
                    k: v["default"] for k, v in self.config_spec.items()
                }
                # Initialize value metadata for defaults
                self.bot.config_value_metadata = {}
                for key in self.bot.config.keys():
                    self.bot.config_value_metadata[key] = {
                        "last_updated": "default",
                        "updated_by": "system"
                    }
                self.bot.logger.info(f"Created default config with {len(self.bot.config)} entries")

        except Exception as e:
            self.bot.logger.error(f"Error loading config or spec: {e}")
            import traceback
            self.bot.logger.error(traceback.format_exc())

    async def save_config(self, hooks_passed=None, modified_key=None, user=None):
        try:
            # Convert the config to a tomlkit document
            doc = tomlkit.document()
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            
            metadata = tomlkit.table()
            metadata.add(tomlkit.comment("Configuration metadata"))
            metadata["last_updated"] = now
            metadata["version"] = "1.0"
            
            # Add hook information if provided
            if hooks_passed:
                metadata["hooks_passed"] = tomlkit.array()
                for hook in hooks_passed:
                    metadata["hooks_passed"].append(hook)
                    
            # Add specific key update info if provided
            if modified_key:
                metadata["last_modified_key"] = modified_key
                if user:
                    metadata["modified_by"] = str(user)
            
            # Add metadata to document
            doc["metadata"] = metadata
            
            # Ensure bot.config is a dict before proceeding
            if not isinstance(self.bot.config, dict):
                self.bot.logger.warning(f"Config is not a dict, it's {type(self.bot.config)}. Converting...")
                config_dict = dict(self.bot.config) if hasattr(self.bot.config, '__iter__') else {}
                self.bot.config = config_dict
                
            # Load existing value_metadata if available
            value_metadata = {}
            if hasattr(self.bot, "config_value_metadata"):
                value_metadata = self.bot.config_value_metadata
            else:
                self.bot.config_value_metadata = {}
                
            # If we're updating a specific key, update its metadata
            if modified_key and modified_key in self.bot.config:
                value_metadata[modified_key] = {
                    "last_updated": now,
                    "updated_by": str(user) if user else "unknown"
                }
                self.bot.config_value_metadata = value_metadata
            
            # Add settings table with all config entries
            settings = tomlkit.table()
            settings.add(tomlkit.comment("User settings"))
            for key, value in self.bot.config.items():
                settings[key] = value
            
            # Add settings to document
            doc["settings"] = settings
            
            # Add value_metadata table
            if value_metadata:
                vm_table = tomlkit.table()
                vm_table.add(tomlkit.comment("Individual value metadata"))
                
                for key, meta in value_metadata.items():
                    if key in self.bot.config:  # Only include metadata for existing keys
                        key_meta = tomlkit.table()
                        for meta_key, meta_value in meta.items():
                            key_meta[meta_key] = meta_value
                        vm_table[key] = key_meta
                        
                doc["value_metadata"] = vm_table
            
            # Write the TOML document to file
            with open(CONFIG_PATH, "w") as f:
                f.write(tomlkit.dumps(doc))
            self.bot.logger.info(f"TOML config saved with {len(self.bot.config)} entries and metadata.")
            
            # Remove the old JSON config if it exists
            if os.path.exists(OLD_CONFIG_PATH):
                try:
                    os.remove(OLD_CONFIG_PATH)
                    self.bot.logger.info("Removed old JSON config file.")
                except Exception as e:
                    self.bot.logger.warning(f"Failed to remove old JSON config: {e}")
                    
        except Exception as e:
            self.bot.logger.error(f"Error saving config: {e}")
            
    def config_hook(self, config_key: str):
        """Decorator to register a config hook function for a specific config key"""
        def decorator(func):
            # Record information about this hook for later registration
            if not hasattr(func, "_config_hooks"):
                func._config_hooks = []
            func._config_hooks.append(config_key)
            return func
        return decorator
    
    def register_hook(self, key: str, cog_instance: commands.Cog, method_name: str) -> None:
        """Register a hook for a config key"""
        if key not in self.bot.config_hooks:
            self.bot.config_hooks[key] = []
        
        # Store tuple of (cog_instance, method_name) for proper calling later
        hook_entry = (cog_instance, method_name)
        
        # Avoid duplicates
        if hook_entry not in self.bot.config_hooks[key]:
            self.bot.config_hooks[key].append(hook_entry)
            self.bot.logger.info(f"Registered hook {cog_instance.__class__.__name__}.{method_name} for {key}")
    
    async def run_hooks(self, key: str, ctx: commands.Context, old_value: Any, new_value: Any) -> bool:
        """Run all hooks for a config key. Returns True if all hooks passed, False otherwise."""
        # Check if there are any hooks for this config key
        if key not in self.bot.config_hooks:
            return True  # No hooks means it passes
            
        # Get all hooks for this key
        hooks = self.bot.config_hooks[key]
        if not hooks:
            return True  # No hooks means it passes
        
        # Run all hooks
        for cog_instance, method_name in hooks:
            self.bot.logger.info(f"Running hook {cog_instance.__class__.__name__}.{method_name} for {key}")
            try:
                hook_method = getattr(cog_instance, method_name)
                hook_result = await hook_method(ctx, old_value, new_value)
                
                self.bot.logger.info(f"Hook {cog_instance.__class__.__name__}.{method_name} returned {hook_result}")
                if hook_result is None:
                    self.bot.respond(ctx, "Error in hook: returned None, murder whoever shows up in git blame. Not applying changes.")
                    return False
                if not hook_result:
                    self.bot.logger.warning(f"Hook {cog_instance.__class__.__name__}.{method_name} rejected value {new_value} for {key}")
                    return False  # Hook rejected the change
            except Exception as e:
                self.bot.logger.error(f"Error running hook {cog_instance.__class__.__name__}.{method_name}: {e}")
                await self.bot.respond(ctx, f"Error in hook: {e}")
                return False
        
        return True  # All hooks passed

    def cast_value(self, value: str, allowed_types: list):
        lowered = value.lower()
        if "bool" in allowed_types:
            if lowered in ["true", "yes", "1"]:
                return True
            if lowered in ["false", "no", "0"]:
                return False

        if "int" in allowed_types:
            try:
                return int(value)
            except ValueError:
                pass

        if "float" in allowed_types:
            try:
                return float(value)
            except ValueError:
                pass

        if "str" in allowed_types:
            return value

        raise ValueError("No valid type matched.")

    @commands.command(name="settings", aliases=["show_config"])
    async def show_config(self, ctx, *args):
        """Displays current config with descriptions and metadata. Use `.settings [page]` for pagination."""
        if not self.bot.config:
            await self.bot.respond(ctx, "Config is empty.")
            return

        # Parse page number
        try:
            page = int(args[0]) if args else 1
            if page < 1:
                raise ValueError
        except ValueError:
            await self.bot.respond(ctx, "Invalid page number. Use `.settings [page]`, e.g., `.settings 2`")
            return

        # Collect config lines
        all_lines = ["**Current config:**"]
        for key, spec in self.config_spec.items():
            val = self.bot.config.get(key, spec["default"])
            typename = type(val).__name__
            desc = spec.get("description", "No description.")
            
            meta_info = ""
            if hasattr(self.bot, "config_value_metadata") and key in self.bot.config_value_metadata:
                meta = self.bot.config_value_metadata[key]
                if "last_updated" in meta:
                    meta_info = f" (Last updated: {meta['last_updated']})"
            
            if isinstance(val, str) and '\n' in val:
                all_lines.append(f"`{key}` ({typename}){meta_info} - {desc}\n{val}")
            else:
                all_lines.append(f"`{key}` ({typename}){meta_info} - {desc}\n> {val}")

        # Pagination logic
        total_pages = math.ceil(len(all_lines) / ITEMS_PER_PAGE)
        if page > total_pages:
            await self.bot.respond(ctx, f"Page {page} out of range. Max page is {total_pages}.")
            return

        start = (page - 1) * ITEMS_PER_PAGE
        end = start + ITEMS_PER_PAGE
        paged_lines = all_lines[start:end]
        paged_lines.append(f"\nPage {page}/{total_pages}")

        # Append global config metadata on the last page only
        if page == total_pages and hasattr(self.bot, "config_file_metadata"):
            paged_lines.append("\n**Global config metadata:**")
            for key, value in self.bot.config_file_metadata.items():
                paged_lines.append(f"{key}: {value}")

        response = await self.bot.respond(ctx, "\n".join(paged_lines))
        if hasattr(response, 'edit'):
            await response.edit(suppress=True)

    @commands.command(name="list_hooks")
    async def list_hooks(self, ctx):
        """Show all registered config hooks"""
        hooks_info = ["**Registered Config Hooks:**"]
        
        for key, hooks in self.bot.config_hooks.items():
            hook_names = [f"{h[0].__class__.__name__}.{h[1]}" for h in hooks]
            hooks_info.append(f"**{key}**: {', '.join(hook_names) or 'No hooks'}")
            
        if not self.bot.config_hooks:
            hooks_info.append("No hooks registered")
            
        await self.bot.respond(ctx, "\n".join(hooks_info))
        
    @commands.command(name="config_meta")
    async def config_meta(self, ctx, key: str = None):
        """Show metadata for config settings. Specify a key for detailed info or leave blank for global metadata."""
        if key is None:
            # Show global metadata
            lines = ["**Global Config Metadata:**"]
            if hasattr(self.bot, "config_file_metadata"):
                metadata = self.bot.config_file_metadata
                for meta_key, meta_value in metadata.items():
                    if isinstance(meta_value, list):
                        lines.append(f"**{meta_key}**:")
                        for item in meta_value:
                            lines.append(f"- {item}")
                    else:
                        lines.append(f"**{meta_key}**: {meta_value}")
            else:
                lines.append("No global metadata available.")
                
            # Show basic info about value metadata
            if hasattr(self.bot, "config_value_metadata") and self.bot.config_value_metadata:
                lines.append(f"\n**Individual Settings with Metadata**: {len(self.bot.config_value_metadata)}")
                lines.append("Use `.config_meta key_name` to see details for a specific setting.")
            
            await self.bot.respond(ctx, "\n".join(lines))
        else:
            # Show metadata for specific key
            if key not in self.bot.config:
                await self.bot.respond(ctx, f"Config key `{key}` not found.")
                return
                
            lines = [f"**Metadata for `{key}`:**"]
            
            # Add current value
            val = self.bot.config[key]
            typename = type(val).__name__
            if isinstance(val, str) and '\n' in val:
                lines.append(f"**Current value** ({typename}):\n{val}")
            else:
                lines.append(f"**Current value** ({typename}):\n> {val}")
            
            # Add description from spec
            if key in self.config_spec:
                desc = self.config_spec[key].get("description", "No description.")
                lines.append(f"**Description**: {desc}")
            
            # Add value metadata
            if hasattr(self.bot, "config_value_metadata") and key in self.bot.config_value_metadata:
                meta = self.bot.config_value_metadata[key]
                lines.append("\n**Value History:**")
                for meta_key, meta_value in meta.items():
                    lines.append(f"**{meta_key}**: {meta_value}")
            else:
                lines.append("\nNo specific metadata available for this key.")
                
            # Add hook information
            if key in self.bot.config_hooks:
                hooks = self.bot.config_hooks[key]
                hook_names = [f"{h[0].__class__.__name__}.{h[1]}" for h in hooks]
                lines.append(f"\n**Hooks**: {', '.join(hook_names)}")
            
            await self.bot.respond(ctx, "\n".join(lines))
        
    @commands.command(name="migrate_config")
    async def migrate_config(self, ctx):
        """Force migration from JSON to TOML config format"""
        try:
            old_config = None
            new_config = None
            migration_metadata = ["Manual migration triggered by user"]
            
            # Check if old JSON config exists
            if os.path.exists(OLD_CONFIG_PATH):
                with open(OLD_CONFIG_PATH, "r") as f:
                    old_config = json.load(f)
                migration_metadata.append(f"Migrated from {OLD_CONFIG_PATH} with {len(old_config)} entries")
                await self.bot.respond(ctx, f"Found JSON config with {len(old_config)} entries.")
            else:
                await self.bot.respond(ctx, "No JSON config file found.")
                
            # Update bot.config if we found a JSON config
            if old_config:
                self.bot.config = old_config
                await self.save_config(migration_metadata)
                
            # Verify TOML config was saved correctly
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "r") as f:
                    toml_data = tomlkit.parse(f.read())
                    if "settings" in toml_data:
                        settings = toml_data["settings"]
                        new_config = {k: v for k, v in settings.items()}
                        await self.bot.respond(ctx, f"TOML config saved with {len(new_config)} entries.")
                        
                        # Show metadata info
                        if "metadata" in toml_data:
                            metadata = toml_data["metadata"]
                            await self.bot.respond(ctx, f"Configuration metadata: Last updated {metadata.get('last_updated', 'unknown')}")
                            if "hooks_passed" in metadata:
                                hooks = metadata["hooks_passed"]
                                if hooks:
                                    await self.bot.respond(ctx, f"Migration info: {', '.join(hooks)}")
                    else:
                        # Legacy format
                        new_config = {k: v for k, v in toml_data.items()}
                        await self.bot.respond(ctx, f"TOML config saved with {len(new_config)} entries (legacy format).")
            else:
                await self.bot.respond(ctx, "TOML config file not created successfully.")
                
            # Provide details about the migration
            if old_config and new_config:
                if len(old_config) == len(new_config):
                    await self.bot.respond(ctx, "✅ Migration successful! All entries were transferred.")
                else:
                    await self.bot.respond(ctx, f"⚠️ Warning: JSON had {len(old_config)} entries but TOML has {len(new_config)}.")
            
        except Exception as e:
            await self.bot.respond(ctx, f"Error during migration: {e}")
            self.bot.logger.error(f"Migration error: {e}")
            import traceback
            self.bot.logger.error(traceback.format_exc())

    @commands.command()
    async def set_config(self, ctx, key: str, *, value: str):
        """Sets a config value with type enforcement and hook validation."""
        spec = self.config_spec.get(key)
        if not spec:
            await self.bot.respond(ctx, f"Key `{key}` not found in config spec.")
            return

        try:
            parsed = self.cast_value(value, spec["types"])
            old_value = self.bot.config.get(key, spec["default"])
            
            # Get all hooks for this key
            hooks_info = []
            if key in self.bot.config_hooks:
                hooks_info = [f"{h[0].__class__.__name__}.{h[1]}" for h in self.bot.config_hooks[key]]
                
            # Run all hooks
            hooks_passed = await self.run_hooks(key, ctx, old_value, parsed)
            if not hooks_passed:
                return  # Hook rejected the change, stop processing
            
            # If we got here, either there are no hooks or all hooks passed
            self.bot.config[key] = parsed
            
            # Get user info for tracking who made the change
            user_info = f"{ctx.author.name}#{ctx.author.discriminator} ({ctx.author.id})"
            
            # Save with hooks information and user tracking
            if hooks_info:
                await self.save_config(hooks_info, key, user_info)
            else:
                await self.save_config(None, key, user_info)
                
            typename = type(parsed).__name__
            self.bot.logger.info(f"Set config key '{key}' to '{parsed}' ({typename}) by {user_info}")
            
            # Show metadata for this key if available
            metadata_info = ""
            if hasattr(self.bot, "config_value_metadata") and key in self.bot.config_value_metadata:
                meta = self.bot.config_value_metadata[key]
            await self.bot.respond(ctx, f"Set `{key}` to `{parsed}` ({typename}).")
        except ValueError:
            allowed = ", ".join(spec["types"])
            await self.bot.respond(ctx, f"Invalid value for `{key}`. Allowed types: {allowed}")


async def setup(bot):
    await bot.add_cog(ConfigCog(bot))

