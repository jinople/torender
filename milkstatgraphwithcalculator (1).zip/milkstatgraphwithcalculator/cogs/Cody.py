import discord
from discord.ext import commands
import os
import aiohttp
import asyncio
import json
from log import logger

class CodyCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_key = os.getenv("SOURCEGRAPH_API_KEY")
        self.api_url = "https://sourcegraph.com/.api/completions/stream"

    @commands.command()
    async def cody(self, ctx, *, question=None):
        """
        Ask Cody (Sourcegraph AI) a coding question
        Usage: .cody [question]
        """
        try:
            if not question:
                await self.bot.respond(ctx, content="Please provide a question.")
                return

            if not self.api_key:
                await self.bot.respond(ctx, content="Sourcegraph API key not configured..")
                return
                
            if len(question) > 1999:
                await self.bot.respond(ctx, content="Input question is too long - must be 1999 characters or less.")
                return

            # Log the question
            logger.info(f"Asking Cody: {question}")

            # Initial message
            await self.bot.respond(ctx, content=f"Generating response...")

            # Get response from Cody (no streaming updates)
            full_response = await self.ask_cody(question)

            logger.info(f"Cody response completed: {'yes' if full_response else 'no'}")

            # Format the final response
            if not full_response:
                await self.bot.respond(ctx, content=f"No response received from Cody.")
            else:
                # Handle Discord's character limit
                formatted_response = full_response
                full_content = f"**Cody:** {formatted_response}"
                
                if len(full_content) > 1900:
                    max_response_length = 1900 - len(f"**Cody:** ") - 50
                    formatted_response = formatted_response[:max_response_length] + "...\n(Response truncated due to Discord's character limit)"
                
                await self.bot.respond(ctx, content=f"**Cody:** {formatted_response}")

        except Exception as e:
            logger.error(f"Error in Cody command: {str(e)}")
            await self.bot.respond(ctx, content=f"Couldn't get an answer from Cody: {str(e)}")

    async def ask_cody(self, question, model=None):
        """Function to ask Cody a question without streaming updates"""
        # Prepare request body
        request_body = {
            "messages": [
                {
                    "speaker": "human",
                    "text": question
                }
            ],
            "temperature": 0.3,
            "maxTokensToSample": 2000,
            "topK": 50,
            "topP": 0.95,
            "model": "openai/gpt-4o"
        }
        
        # Add model if specified
        if model:
            request_body["model"] = model
            
        # Set up headers
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Authorization": f"token {self.api_key}"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.api_url,
                    json=request_body,
                    headers=headers
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        logger.error(f"Cody API error: {response.status} - {error_text}")
                        return None
                        
                    # Process the streaming response
                    buffer = ""
                    full_completion = ""
                    
                    async for chunk in response.content:
                        chunk_text = chunk.decode('utf-8')
                        buffer += chunk_text
                        
                        # Process complete events in the buffer
                        while "\n\n" in buffer:
                            event_end_index = buffer.find("\n\n")
                            event_string = buffer[:event_end_index]
                            buffer = buffer[event_end_index + 2:]
                            
                            # Parse the event
                            lines = event_string.split("\n")
                            if not lines:
                                continue
                                
                            event_type = lines[0].replace("event: ", "")
                            
                            if event_type == "completion":
                                # Find the data line
                                for line in lines:
                                    if line.startswith("data: "):
                                        try:
                                            data = line[6:]  # Remove 'data: ' prefix
                                            json_data = json.loads(data)
                                            
                                            if "completion" in json_data:
                                                # Update the full completion with new content
                                                full_completion = json_data["completion"]
                                        except json.JSONDecodeError as e:
                                            logger.error(f"Failed to parse JSON: {e} - Line: {line}")
                            elif event_type == "error":
                                # Handle error events
                                for line in lines:
                                    if line.startswith("data: "):
                                        try:
                                            data = line[6:]  # Remove 'data: ' prefix
                                            json_data = json.loads(data)
                                            error_msg = json_data.get("error", "Unknown error from Cody API")
                                            logger.error(f"Cody API error: {error_msg}")
                                            return None
                                        except json.JSONDecodeError:
                                            logger.error("Failed to parse error JSON from Cody API")
                            elif event_type == "done":
                                # Streaming is complete
                                return full_completion
            
            return full_completion
        except Exception as e:
            logger.error(f"Error in ask_cody: {str(e)}")
            return None

async def setup(bot):
    await bot.add_cog(CodyCommands(bot))
