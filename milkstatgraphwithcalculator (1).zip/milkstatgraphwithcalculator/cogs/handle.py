import logging
import traceback
from discord.ext import commands

# Set up logger for the error handler
logger = logging.getLogger("Selfbot")
logger.setLevel(logging.DEBUG)

class ErrorHandler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        # Handle CommandNotFound and CommandInvokeError
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore CommandNotFound errors (no response to unknown commands)

        # Handle MissingPermissions
        if isinstance(error, commands.MissingPermissions):
            await self.bot.respond(ctx, "You do not have the required permissions to run this command.")
            logger.warning(f"Permissions error on {ctx.command} by {ctx.author}: {error}")
            return

        # Handle MissingRequiredArgument
        if isinstance(error, commands.MissingRequiredArgument):
            await self.bot.respond(ctx, f"Missing argument: {error.param}")
            logger.warning(f"Missing argument on {ctx.command} by {ctx.author}: {error}")
            return

        # Handle BadArgument (for type conversion issues)
        if isinstance(error, commands.BadArgument):
            await self.bot.respond(ctx, f"Invalid argument provided. Please check the command usage. {error}")
            logger.warning(f"Bad argument error on {ctx.command} by {ctx.author}: {error}")
            return

        # Catch other unexpected errors
        logger.error(f"Unexpected error on {ctx.command} by {ctx.author}: {error}")
        logger.error("".join(traceback.format_exception(type(error), error, error.__traceback__)))

        # Send a generic message to the user
        await self.bot.respond(ctx, "dipshit check logs") # if this causes problems we can fallback on logs or just ctx.edit()

async def setup(bot):
    await bot.add_cog(ErrorHandler(bot))
