import discord
from discord.ext import commands
import asyncio

class AfkCommands(commands.Cog):
    def __init__(self, bot):
        self.bot: commands.Bot = bot
        self.bot.AFK_STATUS = False
        self.bot.AFK_REASON = "None"
        self.bot.AFK_NOTIFIED_MESSAGES = {}  # user_id -> message
        self.gconf = self.bot.get_config

    @commands.command()
    async def afk(self, ctx):
        """
        Enable AFK mode
        Usage: .afk [reason]
        """
        if not self.bot.AFK_STATUS:
            self.bot.AFK_STATUS = True
            reason = ctx.message.content[5:] # ugly haxxor fix
            self.bot.AFK_REASON = reason if reason else False
            await ctx.message.reply(content="k")
            if self.gconf("afk_set_status"):
                await self.bot.change_presence(
                    status=discord.Status.idle,
                    activity=discord.CustomActivity(name=self.gconf("afk_status_message"))
                )
        else:
            await ctx.message.edit(content="You are already in AFK mode.")

    @commands.command()
    async def unafk(self, ctx):
        """
        Disable AFK mode
        Usage: .unafk
        """
        if self.bot.AFK_STATUS:
            self.bot.AFK_STATUS = False

            if self.bot.AFK_NOTIFIED_MESSAGES:
                for user_id, original_msg in self.bot.AFK_NOTIFIED_MESSAGES.items():
                    try:
                        await original_msg.reply("Hey, I'm back, human me will take over now!")
                    except Exception as e:
                        print(f"Error replying to user {user_id}: {e}")

                users_info = [
                    f"\n\\- {user_id} | <@{user_id}>"
                    for user_id in self.bot.AFK_NOTIFIED_MESSAGES
                ]
                await ctx.message.edit(
                    content="should work, here are the people who pinged you:" + "".join(users_info)
                )
            else:
                if self.gconf("afk_set_status"):
                    await self.bot.change_presence(afk=False, status=discord.Status.online)
                await ctx.message.edit(content="nobody pinged you because you're alone asf obvs, anyways wb")

            self.bot.AFK_NOTIFIED_MESSAGES.clear()
        else:
            await ctx.message.edit(content="You are not in AFK mode.")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.id == self.bot.user.id:
            return

        if self.bot.AFK_STATUS:
            is_private = isinstance(message.channel, (discord.DMChannel, discord.GroupChannel))
            allow_public = self.gconf("afk_reply_in_server")

            if is_private or (allow_public and self.bot.user in message.mentions):
                self.bot.AFK_NOTIFIED_MESSAGES[message.author.id] = message
                try:
                    custom_message = self.gconf("afk_custom_reply_message", 
                        "Heya, I'm not at my computer right now. If you're requesting something, please follow <https://nohello.club>. I'll let you know when I'm back :) \n\n-# This action was automated.")
                    await message.reply(custom_message)
                    if self.bot.AFK_REASON:
                        await message.channel.send(f"AFK reason:\n{self.bot.AFK_REASON}")
                except Exception as e:
                    print(f"Failed to send AFK reply to {message.author.id}: {e}")


async def setup(bot):
    await bot.add_cog(AfkCommands(bot))
