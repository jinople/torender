import discord
from discord.ext import commands, tasks
import imaplib
import email
from email.header import decode_header
import os
from log import logger
import asyncio
import json

class GmailCheckerCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.owner_id = 288395032942084096

        # Email configuration (Gmail)
        self.email_address = os.environ.get("EMAIL_ADDRESS", "formulateplot@gmail.com")
        self.email_password = os.environ.get("EMAIL_PASSWORD")  # Gmail app password
        self.imap_server = os.environ.get("IMAP_SERVER", "imap.gmail.com")  # Gmail IMAP
        self.imap_port = int(os.environ.get("IMAP_PORT", "993"))  # Gmail IMAP port
        self.check_interval = int(os.environ.get("EMAIL_CHECK_INTERVAL", "30"))  # Check every 30 seconds
        self.email_channel_id = int(os.environ.get("EMAIL_CHANNEL_ID", "0")) if os.environ.get("EMAIL_CHANNEL_ID") else None

        # Load personality configuration
        self.load_personality()

        # Initialize AI
        self.setup_ai()

        # Track processed emails
        self.processed_emails = set()

        if self.email_password:
            self.email_checker.start()
            logger.info(f"✓ Gmail checker started for {self.email_address}")
        else:
            logger.error("❌ EMAIL_PASSWORD not set! Add it to Replit Secrets.")

    async def cog_unload(self):
        self.email_checker.cancel()
        logger.info("Gmail checker stopped")

    def load_personality(self):
        """Load personality from JSON file"""
        try:
            with open('personality.json', 'r') as f:
                self.personality = json.load(f)
                logger.info(f"Gmail loaded personality: {self.personality.get('name', 'Unknown')}")
        except FileNotFoundError:
            logger.warning("personality.json not found, using defaults")
            self.personality = {
                "name": "Assistant",
                "personality": "You are a helpful assistant.",
                "backstory": "",
                "traits": [],
                "rules": [],
                "temperature": 1.0,
                "max_tokens": 4096
            }
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing personality.json: {e}, using defaults")
            self.personality = {
                "name": "Assistant",
                "personality": "You are a helpful assistant.",
                "backstory": "",
                "traits": [],
                "rules": [],
                "temperature": 1.0,
                "max_tokens": 4096
            }

    def setup_ai(self):
        """Setup AI providers"""
        self.ai_providers = []

        try:
            from groq import Groq
            groq_key = os.environ.get('GROQ_API_KEY')
            if groq_key:
                self.groq_client = Groq(api_key=groq_key)
                self.ai_providers.append('groq')
                logger.info("✓ Gmail: Groq AI initialized")
        except ImportError:
            logger.warning("Groq not available")
        except Exception as e:
            logger.error(f"Failed to initialize Groq: {e}")

        try:
            import google.generativeai as genai
            gemini_key = os.environ.get('GEMINI_API_KEY')
            if gemini_key:
                genai.configure(api_key=gemini_key)
                self.gemini_model = genai.GenerativeModel('gemini-1.5-flash')
                self.ai_providers.append('gemini')
                logger.info("✓ Gmail: Gemini AI initialized (fallback)")
        except ImportError:
            logger.warning("Gemini not available")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")

        if not self.ai_providers:
            logger.error("❌ Gmail: No AI providers available!")

    def build_system_prompt(self):
        """Build system prompt with personality"""
        prompt_parts = []

        if self.personality.get('name'):
            prompt_parts.append(f"Your name is {self.personality['name']}.")

        if self.personality.get('personality'):
            prompt_parts.append(self.personality['personality'])

        if self.personality.get('backstory'):
            prompt_parts.append(f"Your backstory: {self.personality['backstory']}")

        if self.personality.get('traits'):
            traits = [t.strip() for t in self.personality['traits'] if t.strip()]
            if traits:
                prompt_parts.append(f"Your personality traits: {', '.join(traits)}")

        if self.personality.get('rules'):
            rules = [r.strip() for r in self.personality['rules'] if r.strip()]
            if rules:
                prompt_parts.append(f"Important rules to follow: {', '.join(rules)}")

        if self.personality.get('example_responses'):
            examples = self.personality['example_responses']
            example_text = "Example responses for context:\n"
            for situation, response in examples.items():
                example_text += f"- When {situation}: \"{response}\"\n"
            prompt_parts.append(example_text)

        prompt_parts.append("You are helping process emails. Extract confirmation codes, important links, and summarize key information clearly and concisely.")

        return "\n\n".join(prompt_parts)

    def decode_email_text(self, msg):
        """Decode email body text"""
        text = ""

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                if content_type == "text/plain":
                    try:
                        payload = part.get_payload(decode=True)
                        charset = part.get_content_charset() or 'utf-8'
                        text += payload.decode(charset, errors='ignore')
                    except:
                        pass
        else:
            try:
                payload = msg.get_payload(decode=True)
                charset = msg.get_content_charset() or 'utf-8'
                text = payload.decode(charset, errors='ignore')
            except:
                pass

        return text

    async def get_ai_response(self, email_content, from_address, subject):
        """Get AI response about the email"""
        if not self.ai_providers:
            return "AI not available to process email."

        user_message = f"""You received an email:

From: {from_address}
Subject: {subject}

Content:
{email_content}

Please process this email and respond accordingly. If there are confirmation codes or important information, mention them clearly."""

        messages = [
            {"role": "system", "content": self.build_system_prompt()},
            {"role": "user", "content": user_message}
        ]

        for provider in self.ai_providers:
            try:
                if provider == 'groq':
                    return await self.get_groq_response(messages)
                elif provider == 'gemini':
                    return await self.get_gemini_response(messages)
            except Exception as e:
                logger.error(f"Gmail: {provider} failed: {e}")
                continue

        return "Failed to get AI response for email."

    async def get_groq_response(self, messages):
        """Get response from Groq"""
        input_text = " ".join([msg['content'] for msg in messages])
        estimated_input_tokens = len(input_text) // 4
        max_allowed_tokens = 128000
        max_completion_tokens = min(
            self.personality.get('max_tokens', 4096),
            max_allowed_tokens - estimated_input_tokens - 100
        )

        if max_completion_tokens < 100:
            max_completion_tokens = 4096

        completion = self.groq_client.chat.completions.create(
            model="meta-llama/llama-4-maverick-17b-128e-instruct",
            messages=messages,
            max_completion_tokens=max_completion_tokens,
            temperature=self.personality.get('temperature', 1.0),
            top_p=1,
            stream=True,
            stop=None
        )

        full_response = ""
        for chunk in completion:
            if chunk.choices[0].delta.content:
                full_response += chunk.choices[0].delta.content

        return full_response

    async def get_gemini_response(self, messages):
        """Get response from Gemini (fallback)"""
        gemini_messages = []
        system_prompt_content = None

        for msg in messages:
            if msg['role'] == 'system':
                system_prompt_content = msg['content']
            elif msg['role'] == 'user':
                content_text = msg['content']
                if system_prompt_content:
                    content_text = f"System Instructions: {system_prompt_content}\n\n{content_text}"
                    system_prompt_content = None
                gemini_messages.append({"role": "user", "parts": [{"text": content_text}]})
            elif msg['role'] == 'assistant':
                gemini_messages.append({"role": "model", "parts": [{"text": msg['content']}]})

        if not gemini_messages or gemini_messages[-1]['role'] != 'user':
            return "Gemini conversion error."

        response = self.gemini_model.generate_content(gemini_messages, stream=False)
        return response.text

    async def check_email(self):
        """Check Proton email inbox for new messages"""
        if not self.email_password:
            logger.error("Cannot check email: EMAIL_PASSWORD not set")
            return

        try:
            logger.debug(f"Checking {self.email_address} for new emails...")
            # Connect to IMAP server (Gmail)
            mail = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
            mail.login(self.email_address, self.email_password)
            mail.select("inbox")

            # Search for unread emails
            status, messages = mail.search(None, "UNSEEN")

            if status != "OK":
                logger.error("Failed to search emails")
                mail.logout()
                return

            email_ids = messages[0].split()
            
            if email_ids:
                logger.info(f"Found {len(email_ids)} unread email(s)")
            else:
                logger.debug("No new emails")

            for email_id in email_ids:
                if email_id in self.processed_emails:
                    continue

                status, msg_data = mail.fetch(email_id, "(RFC822)")

                if status != "OK":
                    continue

                for response_part in msg_data:
                    if isinstance(response_part, tuple):
                        msg = email.message_from_bytes(response_part[1])

                        # Get subject
                        subject = decode_header(msg["Subject"])[0][0]
                        if isinstance(subject, bytes):
                            subject = subject.decode()

                        # Get sender
                        from_ = msg.get("From")

                        # Get body
                        body = self.decode_email_text(msg)

                        # Get AI response
                        ai_response = await self.get_ai_response(body, from_, subject)

                        # Send to channel or DM
                        try:
                            destination = None
                            
                            # Try to send to specified channel first
                            if self.email_channel_id:
                                try:
                                    destination = self.bot.get_channel(self.email_channel_id)
                                    if not destination:
                                        destination = await self.bot.fetch_channel(self.email_channel_id)
                                    logger.info(f"Sending email notification to channel {self.email_channel_id}")
                                except Exception as e:
                                    logger.warning(f"Could not get channel {self.email_channel_id}: {e}")
                            
                            # Fallback to DM if no channel specified or channel not found
                            if not destination:
                                try:
                                    destination = await self.bot.fetch_user(self.owner_id)
                                    logger.info(f"Sending email notification to DM")
                                except Exception as e:
                                    logger.error(f"Could not DM owner: {e}")
                                    # Last resort: try to find any channel the bot can see
                                    for guild in self.bot.guilds:
                                        for channel in guild.text_channels:
                                            try:
                                                destination = channel
                                                logger.info(f"Using fallback channel: {channel.name} in {guild.name}")
                                                break
                                            except:
                                                continue
                                        if destination:
                                            break

                            if destination:
                                if len(ai_response) > 2000:
                                    chunks = [ai_response[i:i+2000] for i in range(0, len(ai_response), 2000)]
                                    await destination.send(f"📧 **Email from {from_}**\n**Subject:** {subject}\n\n{chunks[0]}")
                                    for chunk in chunks[1:]:
                                        await destination.send(chunk)
                                        await asyncio.sleep(1)
                                else:
                                    await destination.send(f"📧 **Email from {from_}**\n**Subject:** {subject}\n\n{ai_response}")

                                logger.info(f"Sent AI-processed email from {from_}")
                            else:
                                logger.error("No valid destination found to send email notification")

                        except Exception as e:
                            logger.error(f"Failed to send email notification: {e}", exc_info=True)

                        self.processed_emails.add(email_id)

                        if len(self.processed_emails) > 100:
                            self.processed_emails = set(list(self.processed_emails)[-50:])

            mail.logout()

        except imaplib.IMAP4.error as e:
            logger.error(f"IMAP error connecting to {self.imap_server}: {e}")
        except Exception as e:
            logger.error(f"Email check error: {e}", exc_info=True)

    @tasks.loop(seconds=30)
    async def email_checker(self):
        """Periodic task to check emails"""
        try:
            await self.check_email()
        except Exception as e:
            logger.error(f"Error in email checker loop: {e}", exc_info=True)
            
    @email_checker.error
    async def email_checker_error(self, error):
        """Handle errors in the email checker loop"""
        logger.error(f"Email checker loop encountered an error: {error}", exc_info=error)

    @email_checker.before_loop
    async def before_email_checker(self):
        """Wait until bot is ready"""
        await self.bot.wait_until_ready()
        logger.info("Gmail checker task ready to start")

    @commands.command(name='checkmail', aliases=['cm'])
    async def check_mail_command(self, ctx):
        """Manually trigger an email check"""
        if ctx.author.id != self.owner_id:
            await ctx.message.edit(content="Only the bot owner can use this command.")
            return

        await ctx.message.edit(content="Checking Gmail...")
        await self.check_email()
        await ctx.message.edit(content="Email check complete! Check your DMs if there were new emails.")

    @commands.command(name='emailstatus', aliases=['es'])
    async def email_status(self, ctx):
        """Show email checker status"""
        if ctx.author.id != self.owner_id:
            await ctx.message.edit(content="Only the bot owner can use this command.")
            return

        status = "Running ✅" if self.email_checker.is_running() else "Stopped ❌"
        channel_info = f"Channel ID: {self.email_channel_id}" if self.email_channel_id else "DM (no channel set)"
        info = f"""**Gmail Checker Status**
Status: {status}
Email: {self.email_address}
IMAP Server: {self.imap_server}:{self.imap_port}
Check Interval: {self.check_interval}s
Notification: {channel_info}
Processed Emails: {len(self.processed_emails)}
AI Providers: {', '.join(self.ai_providers) if self.ai_providers else 'None'}
Personality: {self.personality.get('name', 'Unknown')}
        """
        await ctx.message.edit(content=info)

async def setup(bot):
    await bot.add_cog(GmailCheckerCog(bot))