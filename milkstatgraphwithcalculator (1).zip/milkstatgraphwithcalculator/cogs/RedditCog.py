import discord
from discord.ext import commands
import re

class RedditLinkReplacer(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.pattern = re.compile(r"\br/[\w\-]+|\bu/[\w\-]+", re.IGNORECASE)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author != self.bot.user:
            return
        if "```" in message.content or "`" in message.content:
            return  # Skip messages with code blocks

        def replace(match):
            text = match.group(0)
            return f"[{text}](<https://www.reddit.com/{text}>)"

        new_content = self.pattern.sub(replace, message.content)
        if new_content != message.content:
            await message.edit(content=new_content)

async def setup(bot):
    await bot.add_cog(RedditLinkReplacer(bot))
