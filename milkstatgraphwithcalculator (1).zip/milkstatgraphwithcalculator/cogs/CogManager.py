from discord.ext import commands
import discord
import asyncio
import os
import traceback
from log import logger


class CogManagerCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.add_listener(self.on_cog_add, 'on_cog_add')
        
        # Register hooks for cogs that are already loaded
        self.bot.loop.create_task(self.register_all_hooks())
        
    async def register_all_hooks(self):
        """Register hooks for all already loaded cogs"""
        await asyncio.sleep(1)  # Give time for other cogs to load
        # Clear existing hooks first to avoid duplicates
        if hasattr(self.bot, 'config_hooks'):
            for key in list(self.bot.config_hooks.keys()):
                self.bot.config_hooks[key] = []
                
        self.bot.logger.info("Registering hooks for all loaded cogs...")
        for cog in list(self.bot.cogs.values()):
            # Check if this cog has hooks defined via _cog_hooks
            cog_class_name = cog.__class__.__name__
            if hasattr(cog, '_cog_hooks'):
                self.bot.logger.info(f"Found _cog_hooks in {cog_class_name}, registering them now")
                if hasattr(self.bot, 'register_config_hook'):
                    for config_key, method_name in cog._cog_hooks:
                        self.bot.register_config_hook(config_key, cog, method_name)
                elif hasattr(self.bot, 'config_hooks'):
                    for config_key, method_name in cog._cog_hooks:
                        # Prepare hooks dictionary for direct registration
                        if config_key not in self.bot.config_hooks:
                            self.bot.config_hooks[config_key] = []
                        # Store tuple of (cog_instance, method_name) for proper calling later
                        hook_entry = (cog, method_name)
                        # Avoid duplicates
                        if hook_entry not in self.bot.config_hooks[config_key]:
                            self.bot.config_hooks[config_key].append(hook_entry)
                            self.bot.logger.info(f"Directly registered hook {cog_class_name}.{method_name} for {config_key}")
                continue
                
            try:
                if hasattr(self.bot, 'register_config_hook'):
                    self.register_cog_hooks(cog)
                elif hasattr(self.bot, 'config_hooks'):
                    self.register_hooks_directly(cog)
            except Exception as e:
                self.bot.logger.error(f"Error registering hooks for {cog.__class__.__name__}: {e}")
    
    async def on_cog_add(self, cog):
        """Automatically register config hooks when a cog is loaded"""
        # Try to register either with ConfigRegistry or directly
        if hasattr(self.bot, 'register_config_hook'):
            self.register_cog_hooks(cog)
        elif hasattr(self.bot, 'config_hooks'):
            # Direct registration if ConfigRegistry isn't loaded but config_hooks exists
            self.bot.logger.warning(f"ConfigRegistry not loaded, using direct hook registration for {cog.__class__.__name__}")
            self.register_hooks_directly(cog)
    
    def register_cog_hooks(self, cog):
        """Register all config hooks in a cog using ConfigRegistry"""
        # First check for _cog_hooks attribute (preferred method)
        if hasattr(cog, '_cog_hooks'):
            for config_key, method_name in cog._cog_hooks:
                self.bot.register_config_hook(config_key, cog, method_name)
                self.bot.logger.info(f"Registered hook {cog.__class__.__name__}.{method_name} for {config_key}")
            return
            
        # Legacy: Look for methods with the 'config_hook:' listener prefix
        if hasattr(cog, '__cog_listeners__'):
            for listener_name, method_name in cog.__cog_listeners__:
                if listener_name.startswith('config_hook:'):
                    config_key = listener_name.split(':', 1)[1]
                    self.bot.register_config_hook(config_key, cog, method_name)
                    self.bot.logger.info(f"Registered hook {cog.__class__.__name__}.{method_name} for {config_key} (listener)")
                
    def register_hooks_directly(self, cog):
        """Register all config hooks directly without ConfigRegistry"""
        if not hasattr(self.bot, 'config_hooks'):
            self.bot.config_hooks = {}
            
        # First check for _cog_hooks attribute (preferred method)
        if hasattr(cog, '_cog_hooks'):
            for config_key, method_name in cog._cog_hooks:
                # Prepare hooks dictionary
                if config_key not in self.bot.config_hooks:
                    self.bot.config_hooks[config_key] = []
                    
                # Store tuple of (cog_instance, method_name) for proper calling later
                hook_entry = (cog, method_name)
                
                # Avoid duplicates
                if hook_entry not in self.bot.config_hooks[config_key]:
                    self.bot.config_hooks[config_key].append(hook_entry)
                    self.bot.logger.info(f"Directly registered hook {cog.__class__.__name__}.{method_name} for {config_key}")
            return
            
        # Legacy: Look for methods with the 'config_hook:' listener prefix
        if hasattr(cog, '__cog_listeners__'):
            for listener_name, method_name in cog.__cog_listeners__:
                if listener_name.startswith('config_hook:'):
                    config_key = listener_name.split(':', 1)[1]
                    
                    # Prepare hooks dictionary
                    if config_key not in self.bot.config_hooks:
                        self.bot.config_hooks[config_key] = []
                        
                    # Store tuple of (cog_instance, method_name) for proper calling later
                    hook_entry = (cog, method_name)
                    
                    # Avoid duplicates
                    if hook_entry not in self.bot.config_hooks[config_key]:
                        self.bot.config_hooks[config_key].append(hook_entry)
                        self.bot.logger.info(f"Directly registered hook {cog.__class__.__name__}.{method_name} for {config_key} (listener)")

    @commands.command(hidden=True)
    async def reload_hooks(self, ctx):
        """Force reload all config hooks from loaded cogs"""
        use_registry = hasattr(self.bot, 'register_config_hook')
        use_direct = hasattr(self.bot, 'config_hooks')
        
        if not use_registry and not use_direct:
            if hasattr(self.bot, 'respond'):
                await self.bot.respond(ctx, "Neither ConfigRegistry cog nor config_hooks are available!")
            else:
                await self.ctx.message.reply("Neither ConfigRegistry cog nor config_hooks are available!")
            return
            
        # Clear existing hooks
        if use_direct:
            self.bot.config_hooks.clear()
        
        # Re-register all hooks from all cogs
        for cog in self.bot.cogs.values():
            if use_registry:
                self.register_cog_hooks(cog)
            elif use_direct:
                self.register_hooks_directly(cog)
        
        # Count hooks
        hooks_count = 0
        if use_direct:
            hooks_count = sum(len(hooks) for hooks in self.bot.config_hooks.values())
        
        # Respond with appropriate method
        if hasattr(self.bot, 'respond'):
            await self.bot.respond(ctx, f"Reloaded {hooks_count} hooks from {len(self.bot.cogs)} cogs.")
        else:
            await self.ctx.message.reply(f"Reloaded {hooks_count} hooks from {len(self.bot.cogs)} cogs.")
    
    @commands.command()
    async def load(self, ctx, cog: str):
        """Load a cog"""
        try:
            await self.bot.load_extension(f"cogs.{cog}")
            logger.info(f" Loaded cog: cogs.{cog}")
            await ctx.message.edit(content=f" Loaded `cogs.{cog}`")
        except Exception as e:
            traceback_str = traceback.format_exc()
            logger.error(f" Failed to load cogs.{cog}:\n{traceback_str}")
            await ctx.message.edit(content=f" Failed to load `cogs.{cog}`: {e}")

    @commands.command()
    async def unload(self, ctx, cog: str):
        """Unload a cog"""
        try:
            await self.bot.unload_extension(f"cogs.{cog}")
            logger.info(f" Unloaded cog: cogs.{cog}")
            await ctx.message.edit(content=f" Unloaded `cogs.{cog}`")
        except Exception as e:
            traceback_str = traceback.format_exc()
            logger.error(f" Failed to unload cogs.{cog}:\n{traceback_str}")
            await ctx.message.edit(content=f" Failed to unload `cogs.{cog}`: {e}")

    @commands.command()
    async def reload(self, ctx, cog: str = None):
        """Reload a specific cog, or all cogs if none given"""
        if cog:
            ext = f"cogs.{cog}"
            try:
                await self.bot.reload_extension(ext)
                logger.info(f" Reloaded cog: {ext}")
                await ctx.message.edit(content=f" Reloaded `{ext}`")
            except Exception as e:
                try:
                    await self.bot.load_extension(ext)
                    logger.info(f" Failed to reload, but loaded cog: {ext}")
                    await ctx.message.edit(content=f" Failed to reload, but successfully loaded `{ext}`, did you make this right now?")
                except Exception as load_e:
                    traceback_str = traceback.format_exc()
                    logger.error(f" Failed to reload/load {ext}:\n{traceback_str}")
                    await ctx.message.edit(content=f" Failed to reload or load `{ext}`: {load_e}")
        else:
            output_lines = []
            tasks = []

            for filename in os.listdir("cogs"):
                if filename.endswith(".py") and not filename.startswith("_"):
                    ext = f"cogs.{filename[:-3]}"

                    async def handle_reload(ext):
                        try:
                            await self.bot.reload_extension(ext)
                            logger.info(f" Reloaded cog: {ext}")
                            return f" {ext}"
                        except Exception:
                            try:
                                await self.bot.load_extension(ext)
                                logger.info(f" Failed to reload, but loaded cog: {ext}")
                                return f" Failed to reload, but successfully loaded {ext}, did you make this right now?"
                            except Exception:
                                traceback_str = traceback.format_exc()
                                logger.error(f" Failed to reload/load {ext}:\n{traceback_str}")
                                return f" {ext} — see logs"

                    tasks.append(asyncio.create_task(handle_reload(ext)))

            results = await asyncio.gather(*tasks)
            await ctx.message.edit(content=" Reloaded/Loaded:\n" + "\n".join(results))


async def setup(bot):
    await bot.add_cog(CogManagerCog(bot))