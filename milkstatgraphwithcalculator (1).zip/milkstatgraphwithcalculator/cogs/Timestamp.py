import discord
from discord.ext import commands
import re
import time
from utils.time_parser import parse_time
from log import logger


class TimestampHandler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.time_pattern = re.compile(
            r'in\s+((?:\d+\s*(?:seconds?|minutes?|hours?|days?|weeks?|s|m|h|d|w)\s*)+)',
            re.IGNORECASE
        )

    def parse_relative_time(self, time_str):
        time_part = time_str.replace('hours', 'h').replace('hour', 'h')
        time_part = time_part.replace('minutes', 'm').replace('minute', 'm')
        time_part = time_part.replace('seconds', 's').replace('second', 's')
        time_part = time_part.replace('days', 'd').replace('day', 'd')
        time_part = time_part.replace('weeks', 'w').replace('week','w')
        time_part = re.sub(r'\s+', '', time_part)

        seconds = parse_time(time_part)
        if seconds:
            return int(time.time() + seconds)
        return None

    def create_discord_timestamp(self, unix_time, format_code='R'):
        timestamp = f"<t:{unix_time}:{format_code}> "
        return timestamp

    def replace_time_patterns(self, content):
        matches = list(self.time_pattern.finditer(content))

        if not matches:
            return content

        result = content

        for match in matches:
            time_str = match.group(1)
            unix_time = self.parse_relative_time(time_str)

            if unix_time:
                timestamp = self.create_discord_timestamp(unix_time)
                result = result.replace(match.group(0), timestamp, 1)

        return result

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.id != self.bot.user.id:
            return

        if message.content.startswith('.'):
            return

        original_content = message.content
        modified_content = self.replace_time_patterns(original_content)

        if modified_content != original_content:
            try:
                await message.edit(content=modified_content)
                logger.info(f"Replaced time in message: '{original_content}' → '{modified_content}'")
            except Exception as e:
                logger.error(f"Failed to edit message: {e}")



async def setup(bot):
    await bot.add_cog(TimestampHandler(bot))