import time
from discord.ext import commands
import discord

class Stalker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.gconf = self.bot.get_config
        self.tracked_users = {}  # user_id: {status, activities, channel_id, last_updated}

    @commands.command()
    async def stalk(self, ctx, user: discord.User, channel: discord.TextChannel = None):
        """Toggle stalking a user. Optionally specify a channel for updates."""

        self.bot.logger.info(f"[stalk] Command invoked by {ctx.author} ({ctx.author.id}) in {ctx.channel}.")

        if user.id in self.tracked_users:
            del self.tracked_users[user.id]
            await self.bot.respond(ctx, f"Stopped stalking {user.name}. You're clean. For now.")
            self.bot.logger.info(f"[stalk] Stopped stalking user {user} ({user.id}).")
            return

        # Check for mutual guilds
        mutual_guilds = [g for g in self.bot.guilds if g.get_member(user.id)]
        self.bot.logger.debug(f"[stalk] Found {len(mutual_guilds)} mutual guild(s) for user {user} ({user.id}).")

        if not mutual_guilds:
            await self.bot.respond(ctx, "I don't share any servers with that user, so I can't stalk them.")
            self.bot.logger.warning(f"[stalk] No mutual guilds with user {user} ({user.id}). Aborting.")
            return


        for guild in mutual_guilds:
            member = guild.get_member(user.id)
            if member:
                self.bot.logger.debug(f"[stalk] Using guild '{guild.name}' ({guild.id}) for presence info.")
                break
        else:
            await self.bot.respond(ctx, "Couldn't fetch user presence from mutual servers.")
            self.bot.logger.warning(
                f"[stalk] Failed to get member object for {user} ({user.id}) despite mutual guilds.")
            return

        target_channel = channel or ctx.channel

        self.tracked_users[user.id] = {
            "status": member.status,
            "activities": list(member.activities),
            "channel_id": target_channel.id,
            "last_updated": time.time()
        }

        await self.bot.respond(ctx, f"Now stalking {user.name}. Reports will go to {getattr(target_channel, 'mention', 'this DM')}.")

        self.bot.logger.info(
            f"[stalk] Started stalking {user} ({user.id}); "
            f"status: {member.status}, activities: {[a.name for a in member.activities]}, "
            f"target_channel: {target_channel} ({target_channel.id})"
        )

    @commands.Cog.listener()
    async def on_presence_update(self, _: discord.Member, after: discord.Member):
        if after.id not in self.tracked_users:
            return

        tracked = self.tracked_users[after.id]
        channel = self.bot.get_channel(tracked["channel_id"])

        if not channel:
            self.bot.logger.warning(
                f"[presence] Channel {tracked['channel_id']} for user {after} ({after.id}) not found."
            )
            return

        updates = []

        # Status change
        prev_status = tracked.get("status")
        if prev_status != after.status:
            status_format = self.gconf("stalker_status_format", "**Status**: `{old_status}` → `{new_status}`")
            updates.append(status_format.format(old_status=prev_status, new_status=after.status))
            self.bot.logger.info(
                f"[presence] Status changed for {after} ({after.id}): {prev_status} → {after.status}"
            )
            tracked["status"] = after.status

        # Normalize activities for comparison
        def simplify_activity(a):
            if isinstance(a, discord.CustomActivity):
                return "custom", a.name or a.state or ""
            return a.type, a.name

        before_set = {simplify_activity(a) for a in tracked.get("activities", [])}
        after_set = {simplify_activity(a) for a in after.activities}

        stopped = before_set - after_set
        started = after_set - before_set

        if stopped:
            stopped_format = self.gconf("stalker_activity_stopped_format", "**Stopped**: {activities}")
            activities_str = ", ".join(f"`{name}`" for _, name in stopped)
            updates.append(stopped_format.format(activities=activities_str))
            self.bot.logger.info(
                f"[presence] {after} ({after.id}) stopped: {', '.join(name for _, name in stopped)}"
            )

        if started:
            started_format = self.gconf("stalker_activity_started_format", "**Started**: {activities}")
            activities_str = ", ".join(f"`{name}`" for _, name in started)
            updates.append(started_format.format(activities=activities_str))
            self.bot.logger.info(
                f"[presence] {after} ({after.id}) started: {', '.join(name for _, name in started)}"
            )

        # Update the tracked state
        tracked["activities"] = list(after.activities)

        if updates:
            # Check cooldown
            now = time.time()
            cooldown = self.gconf("stalker_cooldown", 5)
            last_update = tracked.get("last_updated", 0)
            
            if now - last_update >= cooldown:
                update_format = self.gconf("stalker_update_format", "Update on {username}:\n{updates}")
                message = update_format.format(
                    username=after.name,
                    mention=after.mention,
                    updates="\n".join(updates)
                )
                await channel.send(message)
                tracked["last_updated"] = now
                self.bot.logger.debug(
                    f"[presence] Sent update for {after} ({after.id}) to channel {channel} ({channel.id})"
                )


async def setup(_):
    await _.add_cog(Stalker(_))