import discord
from discord.ext import commands
import asyncio

class UtilityCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.logger = bot.logger  # Use the bot's logger
        self.logger.info("UtilityCog initialized")

    @commands.command(name="ping")
    async def ping(self, ctx):
        """Check the bot's latency."""
        latency = round(self.bot.latency * 1000, 2)  # Convert to milliseconds
        await ctx.send(f"Pong! Latency: {latency}ms")
        self.logger.info(f"Ping command executed by {ctx.author}")

    @commands.command(name="say")
    async def say(self, ctx, *, message: str):
        """Make the bot repeat a message and delete the original."""
        try:
            await ctx.message.delete()  # Delete the command message
            await ctx.send(message)
            self.logger.info(f"Say command: {message}")
        except discord.Forbidden:
            await ctx.send("I don't have permission to delete messages!")
            self.logger.warning("Failed to delete message in say command")

    @commands.command(name="setconfig")
    async def set_config(self, ctx, key: str, *, value: str):
        """Set a config value (stored in bot.config)."""
        self.bot.config[key] = value
        await ctx.send(f"Set config: {key} = {value}")
        self.logger.info(f"Config updated: {key} = {value}")

    @commands.command(name="getconfig")
    async def get_config(self, ctx, key: str):
        """Get a config value."""
        value = self.bot.get_config(key, "Not found")
        await ctx.send(f"Config {key}: {value}")
        self.logger.info(f"Config retrieved: {key} = {value}")

    @commands.Cog.listener()
    async def on_message(self, message):
        """Example listener: Log messages from the bot user."""
        if message.author == self.bot.user:
            self.logger.debug(f"Self-bot message: {message.content}")
        await self.bot.process_commands(message)  # Ensure commands still process

async def setup(bot):
    await bot.add_cog(UtilityCog(bot))