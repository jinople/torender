import os
import discord
from discord.ext import commands
import random
import asyncio
from collections import deque
import datetime
from log import logger
import json

# Force reload Replit secrets if needed
if 'REPL_ID' in os.environ:
    try:
        from replit import db
        _ = db
    except:
        pass

# AI Provider imports
try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    logger.warning("Groq not installed. Run: pip install groq")

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    logger.info("Gemini not installed (backup provider)")

class ShapesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.min_delay = 4.79
        self.max_delay = 19.7
        self.conversation_history = {}
        self.MAX_HISTORY_LENGTH = 10
        self.OWNER_IDS = {self.bot.user.id, 288395032942084096, 1168626335942455326, 845332948524859412, 1236667927944761396, 1184356240923574324}

        # Load personality configuration
        self.load_personality()

        # Initialize AI providers (Groq first!)
        self.ai_providers = []

        groq_key = os.environ.get('GROQ_API_KEY')

        # Setup Groq as PRIMARY
        if GROQ_AVAILABLE and groq_key:
            try:
                self.groq_client = Groq(api_key=groq_key)
                self.ai_providers.append('groq')
                logger.info("✓ Groq AI provider initialized successfully (PRIMARY)")
            except Exception as e:
                logger.error(f"Failed to initialize Groq client: {e}")
        else:
            if not GROQ_AVAILABLE:
                logger.error("Groq library not installed. Run: pip install groq")
            if not groq_key:
                logger.error("GROQ_API_KEY not found in environment variables")

        # Setup Gemini as FALLBACK only
        if GEMINI_AVAILABLE and os.environ.get('GEMINI_API_KEY'):
            try:
                genai.configure(api_key=os.environ.get('GEMINI_API_KEY'))
                self.gemini_model = genai.GenerativeModel('models/gemini-flash-latest')
                self.ai_providers.append('gemini')
                logger.info("✓ Gemini AI provider initialized (fallback) using 'models/gemini-flash-latest'")
            except Exception as e:
                logger.error(f"Failed to initialize Gemini: {e}")

        if not self.ai_providers:
            logger.error("❌ No AI providers available! Add GROQ_API_KEY to Replit Secrets.")
        else:
            logger.info(f"✓ AI providers loaded: {self.ai_providers}")

    def load_personality(self):
        """Load personality from JSON file or use defaults"""
        try:
            with open('personality.json', 'r') as f:
                self.personality = json.load(f)
                logger.info(f"Loaded personality: {self.personality.get('name', 'Unknown')}")
        except FileNotFoundError:
            logger.warning("personality.json not found, using defaults")
            self.personality = {
                "name": "Assistant",
                "personality": "You are a helpful assistant.",
                "backstory": "",
                "traits": [],
                "rules": [],
                "temperature": 1.0,
                "max_tokens": 4096  # Updated default
            }
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing personality.json: {e}, using defaults")
            self.personality = {
                "name": "Assistant",
                "personality": "You are a helpful assistant.",
                "backstory": "",
                "traits": [],
                "rules": [],
                "temperature": 1.0,
                "max_tokens": 4096  # Updated default
            }

    def build_system_prompt(self, username, replied_to_name=None):
        """Build the complete system prompt with personality"""
        prompt_parts = []

        # Add name if specified
        if self.personality.get('name'):
            prompt_parts.append(f"Your name is {self.personality['name']}.")

        # Add personality
        if self.personality.get('personality'):
            prompt_parts.append(self.personality['personality'])

        # Add backstory
        if self.personality.get('backstory'):
            prompt_parts.append(f"Your backstory: {self.personality['backstory']}")

        # Add traits
        if self.personality.get('traits'):
            traits = [t.strip() for t in self.personality['traits'] if t.strip()]
            if traits:
                prompt_parts.append(f"Your personality traits: {', '.join(traits)}")

        # Add rules
        if self.personality.get('rules'):
            rules = [r.strip() for r in self.personality['rules'] if r.strip()]
            if rules:
                prompt_parts.append(f"Important rules to follow: {', '.join(rules)}")

        # Add example responses if they exist
        if self.personality.get('example_responses'):
            examples = self.personality['example_responses']
            example_text = "Example responses for context:\n"
            for situation, response in examples.items():
                example_text += f"- When {situation}: \"{response}\"\n"
            prompt_parts.append(example_text)

        # Modified user context - emphasize NOT using the name
        prompt_parts.append(f"The user's name is {username} but DO NOT use their name in responses unless they specifically ask who they are or you need to talk about them specifically. Just talk to them naturally without using their name.")

        if replied_to_name:
            prompt_parts.append(f"They are replying to a message from {replied_to_name}. Only mention this person's name if relevant to the conversation.")

        return "\n\n".join(prompt_parts)

    async def get_ai_response(self, messages, user_id, channel_id):
        """Get response from AI providers - Groq first, then fallback"""
        for provider in self.ai_providers:
            try:
                if provider == 'groq':
                    return await self.get_groq_response(messages)
                elif provider == 'gemini':
                    logger.warning("Groq failed, falling back to Gemini...")
                    return await self.get_gemini_response(messages)
            except Exception as e:
                logger.error(f"{provider} failed: {e}")
                continue

        return "I'm having trouble connecting to my AI service right now. Please try again later."

    async def get_groq_response(self, messages):
        """Get response from Groq (PRIMARY) with streaming"""
        # Estimate input tokens (rough heuristic: 1 token ~ 4 chars)
        input_text = " ".join([msg['content'] for msg in messages])
        estimated_input_tokens = len(input_text) // 4
        max_allowed_tokens = 128000  # Model's max context window
        max_completion_tokens = min(
            self.personality.get('max_tokens', 4096),
            max_allowed_tokens - estimated_input_tokens - 100  # Buffer for safety
        )

        if max_completion_tokens < 100:
            logger.warning("Input too large, truncating history to fit.")
            messages = messages[:2]  # Keep system prompt and latest user message
            max_completion_tokens = 4096  # Reset to reasonable value

        completion = self.groq_client.chat.completions.create(
            model="meta-llama/llama-4-maverick-17b-128e-instruct",
            messages=messages,
            max_completion_tokens=max_completion_tokens,
            temperature=self.personality.get('temperature', 1.0),
            top_p=1,
            stream=True,
            stop=None
        )

        # Collect streamed response
        full_response = ""
        for chunk in completion:
            if chunk.choices[0].delta.content:
                full_response += chunk.choices[0].delta.content

        return full_response

    async def get_gemini_response(self, messages):
        """Get response from Gemini (FALLBACK ONLY)"""
        gemini_messages = []
        system_prompt_content = None

        for msg in messages:
            if msg['role'] == 'system':
                system_prompt_content = msg['content']
            elif msg['role'] == 'user':
                content_text = msg['content']
                if system_prompt_content:
                    content_text = f"System Instructions: {system_prompt_content}\n\n{content_text}"
                    system_prompt_content = None
                gemini_messages.append({"role": "user", "parts": [{"text": content_text}]})
            elif msg['role'] == 'assistant':
                gemini_messages.append({"role": "model", "parts": [{"text": msg['content']}]})

        if not gemini_messages or gemini_messages[-1]['role'] != 'user':
            logger.error("Gemini conversion error: Last message is not 'user'. Cannot generate content.")
            return "I encountered an internal error trying to use Gemini (invalid message format)."

        response = await self.gemini_model.generate_content(gemini_messages, stream=False)
        return response.text

    async def send_long_message(self, message, content):
        """Splits a long message into chunks and sends them."""
        char_limit = 2000
        chunks = [content[i:i+char_limit] for i in range(0, len(content), char_limit)]

        if chunks:
            try:
                await message.reply(chunks[0])
            except discord.NotFound:
                await message.channel.send(chunks[0])

        for chunk in chunks[1:]:
            await message.channel.send(chunk)
            await asyncio.sleep(1)

    async def edit_and_send_long_message(self, message, content):
        """Edits the original message with the first chunk, then sends subsequent chunks"""
        char_limit = 2000
        chunks = [content[i:i+char_limit] for i in range(0, len(content), char_limit)]

        if chunks:
            await message.edit(content=chunks[0])

        for chunk in chunks[1:]:
            await message.channel.send(chunk)
            await asyncio.sleep(1)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user or message.author.bot:
            return

        if isinstance(message.channel, discord.DMChannel) or self.bot.user in message.mentions:
            # Check if it's a command
            is_command = False
            for prefix in self.bot.command_prefix:
                content = message.content
                if content.startswith(f'<@{self.bot.user.id}>'):
                    content = content[len(f'<@{self.bot.user.id}>'):].strip()

                if content.startswith(prefix):
                    is_command = True
                    break

            if is_command:
                return

            # Log the message
            try:
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_message = f"[{timestamp}] {message.author}: {message.content}\n"
                with open("chat.log", "a", encoding="utf-8") as f:
                    f.write(log_message)
            except Exception as e:
                logger.error(f"Failed to write to chat log: {e}")

            user_id = message.author.id
            user_message = message.content

            # Add delay for non-owners
            if user_id not in self.OWNER_IDS:
                if random.randint(1, 100) == 1:
                    logger.info("Skipping response due to 1% chance.")
                    return
                delay = random.uniform(self.min_delay, self.max_delay)
                logger.info(f"Adding a {delay:.2f} second delay before responding.")
                await asyncio.sleep(delay)
            else:
                logger.info("Bypassing delay for owner.")

            # Get channel history
            try:
                channel_messages = []
                async for msg in message.channel.history(limit=10):
                    if msg.author == self.bot.user:
                        role = "assistant"
                    elif not msg.author.bot:
                        role = "user"
                    else:
                        continue
                    channel_messages.append({"role": role, "content": msg.content})
                channel_messages.reverse()
            except Exception as e:
                logger.error(f"Error fetching channel history: {e}")
                channel_messages = []

            # Check for replied-to message
            replied_to_name = None
            if message.reference and message.reference.message_id:
                try:
                    original_message = await message.channel.fetch_message(message.reference.message_id)
                    replied_to_name = original_message.author.display_name
                except Exception as e:
                    logger.error(f"Error fetching original message: {e}")

            # Manage conversation history
            if user_id not in self.conversation_history:
                self.conversation_history[user_id] = deque(maxlen=self.MAX_HISTORY_LENGTH)

            # Build messages for AI
            messages_for_ai = [{"role": "system", "content": self.build_system_prompt(message.author.name, replied_to_name)}]
            filtered_channel_messages = [msg for msg in channel_messages if msg['role'] != 'system']
            messages_to_send_to_ai = messages_for_ai + filtered_channel_messages
            messages_to_send_to_ai.append({"role": "user", "content": user_message})

            # Update conversation history for the current user
            self.conversation_history[user_id].append({"role": "user", "content": user_message})

            try:
                async with message.channel.typing():
                    await asyncio.sleep(1)

                    # Get AI response (Groq by default!)
                    ai_response = await self.get_ai_response(
                        messages_to_send_to_ai,
                        user_id, 
                        message.channel.id
                    )

                    # Update conversation history with the bot's response
                    self.conversation_history[user_id].append({"role": "assistant", "content": ai_response})

                # Log bot response
                try:
                    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    log_message = f"[{timestamp}] {self.bot.user}: {ai_response}\n"
                    with open("chat.log", "a", encoding="utf-8") as f:
                        f.write(log_message)
                except Exception as e:
                    logger.error(f"Failed to write bot response to chat log: {e}")

                await self.send_long_message(message, ai_response)
                logger.info(f"Response sent to: {message.content}")

            except Exception as e:
                logger.error(f"Error: {str(e)}", exc_info=e)
                await message.channel.send(f"Error: {str(e)}")

    @commands.command(name='ask', aliases=['a'])
    async def shapes_command(self, ctx, *, prompt: str):
        """Sends a message to the AI and replies with the response."""
        user_id = ctx.author.id
        user_message = prompt

        # Log the command
        try:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_message = f"[{timestamp}] {ctx.author}: {ctx.message.content}\n"
            with open("chat.log", "a", encoding="utf-8") as f:
                f.write(log_message)
        except Exception as e:
            logger.error(f"Failed to write command message to chat log: {e}")

        # Check if owner for delay bypass
        if ctx.author.id not in self.OWNER_IDS:
            delay = random.uniform(self.min_delay, self.max_delay)
            logger.info(f"Adding a {delay:.2f} second delay before responding.")
            await asyncio.sleep(delay)
        else:
            logger.info("Bypassing delay for owner.")

        if user_id not in self.conversation_history:
            self.conversation_history[user_id] = deque(maxlen=self.MAX_HISTORY_LENGTH)

        # Get channel history
        try:
            channel_messages = []
            async for msg in ctx.channel.history(limit=10):
                if msg.author == self.bot.user:
                    role = "assistant"
                elif not msg.author.bot:
                    role = "user"
                else:
                    continue
                channel_messages.append({"role": role, "content": msg.content})
            channel_messages.reverse()
        except Exception as e:
            logger.error(f"Error fetching channel history: {e}")
            channel_messages = []

        # Prepare messages for AI
        messages_for_ai = [{"role": "system", "content": self.build_system_prompt(ctx.author.name)}]
        filtered_channel_messages = [msg for msg in channel_messages if msg['role'] != 'system']
        messages_to_send_to_ai = messages_for_ai + filtered_channel_messages
        messages_to_send_to_ai.append({"role": "user", "content": user_message})

        # Update conversation history
        self.conversation_history[user_id].append({"role": "user", "content": user_message})

        try:
            async with ctx.channel.typing():
                # Get AI response
                ai_response = await self.get_ai_response(
                    messages_to_send_to_ai,
                    user_id,
                    ctx.channel.id
                )

                self.conversation_history[user_id].append({"role": "assistant", "content": ai_response})

            # Log bot response
            try:
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_message = f"[{timestamp}] {self.bot.user}: {ai_response}\n"
                with open("chat.log", "a", encoding="utf-8") as f:
                    f.write(log_message)
            except Exception as e:
                logger.error(f"Failed to write bot response to chat log: {e}")

            # Handle long messages
            if len(ai_response) > 2000:
                await self.edit_and_send_long_message(ctx.message, ai_response)
            else:
                await ctx.message.edit(content=ai_response)
                logger.info(f"Command response to: {prompt}")

        except Exception as e:
            logger.error(f"Command error: {str(e)}", exc_info=e)
            await ctx.send(f"Command error: {str(e)}")

    @commands.command(name='personality', aliases=['p'])
    async def show_personality(self, ctx):
        """Show current personality settings"""
        name = self.personality.get('name', 'Not set')
        personality = self.personality.get('personality', 'Not set')[:100]
        if len(self.personality.get('personality', '')) > 100:
            personality += "..."

        info = f"""**Current Personality:**
Name: {name}
Personality: {personality}
Traits: {', '.join(self.personality.get('traits', [])[:3])}
        """
        await ctx.message.edit(content=info)

    @commands.command(name='reload_personality', aliases=['rp'])
    async def reload_personality(self, ctx):
        """Reload personality from personality.json"""
        if ctx.author.id not in self.OWNER_IDS:
            await ctx.message.edit(content="Only bot owners can reload personality.")
            return

        self.load_personality()
        response = f"Personality reloaded! Now acting as: {self.personality.get('name', 'Unknown')}"
        await ctx.message.edit(content=response)

    async def cog_load(self):
        logger.info(f"ShapesCog loaded with providers: {self.ai_providers}")
        if self.ai_providers and self.ai_providers[0] == 'groq':
            logger.info("Using Groq as primary AI provider with Llama 4 Maverick")

async def setup(bot):
    await bot.add_cog(ShapesCog(bot))