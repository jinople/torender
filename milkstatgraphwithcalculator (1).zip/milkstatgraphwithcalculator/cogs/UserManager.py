import discord
from discord.ext import commands
import asyncio


class UserManagementCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.gconf = self.bot.get_config
        self.delete_in_progress = False

    @commands.command()
    async def close(self, ctx):
        """
        Close the DM channel
        Usage: .close
        """
        try:
            # Only works in DM channels
            if isinstance(ctx.channel, discord.DMChannel):
                await self.bot.respond(ctx, " Closing DM...")
                await asyncio.sleep(1)  # Give a second for the message to be seen
                await ctx.channel.close()
            else:
                await self.bot.respond(ctx, " This command only works in DM channels.")
        except Exception as e:
            await self.bot.respond(ctx, f" Error closing DM: {str(e)}")

    @commands.command()
    async def block(self, ctx):
        """
        Block a user using Discord's native block function
        Usage: .block @user or .block [in reply to a message]
        """
        try:
            # Check if we have a mention or if it's a reply
            if ctx.message.mentions:
                user = ctx.message.mentions[0]
            elif ctx.message.reference and ctx.message.reference.resolved:
                user = ctx.message.reference.resolved.author
            else:
                await self.bot.respond(ctx, " Usage: `.block @user` or reply to a message with `.block`")
                return

            if user == self.bot.user:
                await self.bot.respond(ctx, " Cannot block yourself.")
                return

            await user.block()
            await self.bot.respond(ctx, f" Blocked {user.name}#{user.discriminator}")
        except Exception as e:
            await self.bot.respond(ctx, f" Error blocking user: {str(e)}")

    @commands.command()
    async def unblock(self, ctx):
        """
        Unblock a user
        Usage: .unblock @user or user_id
        """
        try:
            content = ctx.message.content.strip()

            # Check if we have a mention
            if ctx.message.mentions:
                user = ctx.message.mentions[0]
                await user.unblock()
                await self.bot.respond(ctx, f" Unblocked user {user.name}#{user.discriminator}.")
                return

            # Try to get user by ID
            parts = content.split()
            if len(parts) >= 2:
                try:
                    user_id = int(parts[1])
                    user = await self.bot.fetch_user(user_id)
                    await user.unblock()
                    await self.bot.respond(ctx, f" Unblocked user {user.name}#{user.discriminator}.")
                except:
                    await ctx.message.edit(content=" Could not find user with that ID.")
            else:
                await ctx.message.edit(content=" Usage: `.unblock @user` or `.unblock user_id`")
        except Exception as e:
            await ctx.message.edit(content=f" Error unblocking user: {str(e)}")

    @commands.command()
    async def delete(self, ctx, *, args=None):
        """
        Delete your recent messages in this channel
        Usage: .delete [amount] | .delete all | .delete multi [amount] | .delete multi all | .delete stop
        """
        if self.delete_in_progress and args != "stop":
            await self.bot.respond(ctx, " Delete operation already in progress. Please wait.")
            return

        if not args:
            # Default: delete 1 message
            await self._delete_messages(ctx, 1)
        elif args == "stop":
            # Stop operation
            await self._delete_stop(ctx)
        elif args == "all":
            # Delete all in current channel
            await self._delete_all_current_channel(ctx)
        elif args.startswith("multi"):
            # Handle multi-channel operations
            parts = args.split()
            print(f"DEBUG: args='{args}', parts={parts}, len={len(parts)}")  # Debug line
            if len(parts) == 1:
                # .delete multi (default 10 per channel)
                await self._delete_multi_channel(ctx, 10)
            elif len(parts) == 2:
                if parts[1] == "all":
                    # .delete multi all
                    await self._delete_multi_all(ctx)
                else:
                    try:
                        amount = int(parts[1])
                        print(f"DEBUG: Parsed amount as {amount}")  # Debug line
                        # .delete multi [amount]
                        await self._delete_multi_channel(ctx, amount)
                    except ValueError:
                        await self.bot.respond(ctx, f" Invalid amount '{parts[1]}'. Usage: `.delete multi [amount]` or `.delete multi all`")
            else:
                await self.bot.respond(ctx, f" Too many arguments ({len(parts)} parts: {parts}). Usage: `.delete multi [amount]` or `.delete multi all`")
        else:
            # Try to parse as number
            try:
                amount = int(args)
                await self._delete_messages(ctx, amount)
            except ValueError:
                await self.bot.respond(ctx, " Invalid command. Usage: `.delete [amount]`, `.delete all`, `.delete multi [amount]`, `.delete multi all`, or `.delete stop`")

    async def _delete_messages(self, ctx, amount):
        """Delete specified number of messages in current channel"""
        try:
            self.delete_in_progress = True
            deleted_count = 0

            # Get message history
            async for message in ctx.channel.history(limit=amount * 2):
                if message.author == self.bot.user and deleted_count < amount:
                    try:
                        await message.delete()
                        deleted_count += 1

                        # 1.5 second delay between deletions
                        await asyncio.sleep(1.5)

                        # Update progress every 10 deletions
                        if deleted_count % 10 == 0:
                            print(f"Deleted {deleted_count}/{amount} messages...")

                    except discord.NotFound:
                        continue
                    except discord.Forbidden:
                        await self.bot.respond(ctx, f" No permission to delete messages. Stopped at {deleted_count} deletions.")
                        break
                    except Exception as e:
                        print(f"Error deleting message: {e}")
                        continue

                if deleted_count >= amount:
                    break

            self.delete_in_progress = False

            if deleted_count > 0:
                # Send a temporary status message
                status_msg = await ctx.send(f" Deleted {deleted_count} messages.")
                await asyncio.sleep(3)
                try:
                    await status_msg.delete()
                except:
                    pass
            else:
                await self.bot.respond(ctx, " No messages found to delete.")

        except Exception as e:
            self.delete_in_progress = False
            await self.bot.respond(ctx, f" Error during deletion: {str(e)}")

    async def _delete_all_current_channel(self, ctx):
        """Delete ALL your messages in current channel"""
        # Confirmation step
        confirm_msg = await ctx.send(" ⚠️ This will delete ALL your messages in this channel! Type 'CONFIRM' within 30 seconds to proceed.")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.upper() == 'CONFIRM'

        try:
            await self.bot.wait_for('message', check=check, timeout=30.0)
        except asyncio.TimeoutError:
            await confirm_msg.edit(content=" Deletion cancelled - timeout.")
            return

        try:
            await confirm_msg.delete()
        except:
            pass

        try:
            self.delete_in_progress = True
            deleted_count = 0

            # Get ALL message history
            async for message in ctx.channel.history(limit=None):
                if message.author == self.bot.user:
                    try:
                        await message.delete()
                        deleted_count += 1

                        # 1.5 second delay between deletions
                        await asyncio.sleep(1.5)

                        # Update progress every 25 deletions
                        if deleted_count % 25 == 0:
                            print(f"Deleted {deleted_count} messages...")

                    except discord.NotFound:
                        continue
                    except discord.Forbidden:
                        print(f"No permission to delete messages. Stopped at {deleted_count} deletions.")
                        break
                    except Exception as e:
                        print(f"Error deleting message: {e}")
                        continue

            self.delete_in_progress = False
            print(f"Deletion complete. Total deleted: {deleted_count} messages.")

        except Exception as e:
            self.delete_in_progress = False
            print(f"Error during mass deletion: {str(e)}")

    async def _delete_multi_channel(self, ctx, amount):
        """Delete messages across multiple channels"""
        # Confirmation step
        confirm_msg = await ctx.send(f" ⚠️ This will delete up to {amount} of your messages in EVERY channel in this server! Type 'CONFIRM' within 30 seconds to proceed.")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.upper() == 'CONFIRM'

        try:
            await self.bot.wait_for('message', check=check, timeout=30.0)
        except asyncio.TimeoutError:
            await confirm_msg.edit(content=" Multi-channel deletion cancelled - timeout.")
            return

        try:
            await confirm_msg.delete()
        except:
            pass

        try:
            self.delete_in_progress = True
            total_deleted = 0

            # Get all text channels in the server
            if ctx.guild:
                channels = [ch for ch in ctx.guild.text_channels if ch.permissions_for(ctx.guild.me).read_messages]

                for channel in channels:
                    channel_deleted = 0
                    print(f"Processing channel: #{channel.name}")

                    try:
                        async for message in channel.history(limit=None if amount == 0 else amount * 2):
                            if message.author == self.bot.user and (amount == 0 or channel_deleted < amount):
                                try:
                                    await message.delete()
                                    channel_deleted += 1
                                    total_deleted += 1

                                    # 1.5 second delay between deletions
                                    await asyncio.sleep(1.5)

                                except discord.NotFound:
                                    continue
                                except discord.Forbidden:
                                    print(f"No permission in #{channel.name}")
                                    break
                                except Exception as e:
                                    print(f"Error in #{channel.name}: {e}")
                                    continue

                            if amount > 0 and channel_deleted >= amount:
                                break

                        print(f"Deleted {channel_deleted} messages from #{channel.name}")

                    except discord.Forbidden:
                        print(f"Cannot access #{channel.name}")
                        continue
                    except Exception as e:
                        print(f"Error processing #{channel.name}: {e}")
                        continue

                self.delete_in_progress = False
                print(f"Multi-channel deletion complete. Total deleted: {total_deleted} messages across {len(channels)} channels.")
            else:
                await self.bot.respond(ctx, " This command only works in servers, not DMs.")
                self.delete_in_progress = False

        except Exception as e:
            self.delete_in_progress = False
            print(f"Error during multi-channel deletion: {str(e)}")

    async def _delete_multi_all(self, ctx):
        """Delete ALL messages across ALL channels"""
        # Double confirmation for this extreme operation
        confirm_msg = await ctx.send(" 🚨 This will delete ALL your messages in EVERY channel in this server!\nType 'I UNDERSTAND THE RISKS' within 30 seconds to proceed.")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.upper() == 'I UNDERSTAND THE RISKS'

        try:
            await self.bot.wait_for('message', check=check, timeout=30.0)
        except asyncio.TimeoutError:
            await confirm_msg.edit(content=" Multi-channel deletion cancelled - timeout.")
            return

        # Second confirmation
        confirm_msg2 = await ctx.send(" Final confirmation: Type 'DELETE EVERYTHING' to proceed with total deletion.")

        def check2(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.upper() == 'DELETE EVERYTHING'

        try:
            await self.bot.wait_for('message', check=check2, timeout=30.0)
        except asyncio.TimeoutError:
            await confirm_msg2.edit(content=" Multi-channel deletion cancelled - timeout.")
            return

        try:
            await confirm_msg.delete()
            await confirm_msg2.delete()
        except:
            pass

        try:
            self.delete_in_progress = True
            total_deleted = 0

            # Get all text channels in the server
            if ctx.guild:
                channels = [ch for ch in ctx.guild.text_channels if ch.permissions_for(ctx.guild.me).read_messages]

                print(f"Starting TOTAL deletion across {len(channels)} channels...")

                for channel in channels:
                    channel_deleted = 0
                    print(f"Processing channel: #{channel.name}")

                    try:
                        # Delete ALL messages in each channel
                        async for message in channel.history(limit=None):
                            if message.author == self.bot.user:
                                try:
                                    await message.delete()
                                    channel_deleted += 1
                                    total_deleted += 1

                                    # 1.5 second delay between deletions
                                    await asyncio.sleep(1.5)

                                    # Progress update every 50 deletions
                                    if total_deleted % 50 == 0:
                                        print(f"Total deleted so far: {total_deleted} messages...")

                                except discord.NotFound:
                                    continue
                                except discord.Forbidden:
                                    print(f"No permission in #{channel.name}")
                                    break
                                except Exception as e:
                                    print(f"Error in #{channel.name}: {e}")
                                    continue

                        print(f"Deleted {channel_deleted} messages from #{channel.name}")

                    except discord.Forbidden:
                        print(f"Cannot access #{channel.name}")
                        continue
                    except Exception as e:
                        print(f"Error processing #{channel.name}: {e}")
                        continue

                self.delete_in_progress = False
                print(f"TOTAL DELETION COMPLETE. Deleted {total_deleted} messages across {len(channels)} channels.")
            else:
                await self.bot.respond(ctx, " This command only works in servers, not DMs.")
                self.delete_in_progress = False

        except Exception as e:
            self.delete_in_progress = False
            print(f"Error during total deletion: {str(e)}")

    async def _delete_stop(self, ctx):
        """Stop any ongoing delete operation"""
        if self.delete_in_progress:
            self.delete_in_progress = False
            await self.bot.respond(ctx, " Delete operation stopped.")
        else:
            await self.bot.respond(ctx, " No delete operation in progress.")

    # Method to check if a channel is ignored
    def is_channel_ignored(self, channel_id):
        return channel_id in self.ignored_channels

    # Method to check if a channel is muted
    def is_channel_muted(self, channel_id):
        return channel_id in self.muted_channels


async def setup(bot):
    await bot.add_cog(UserManagementCommands(bot))