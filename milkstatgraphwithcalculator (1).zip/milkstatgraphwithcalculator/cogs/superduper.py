import discord
from discord.ext import commands, tasks
import asyncio
import aiohttp
import json
import random
import re
import base64
from datetime import datetime, timedelta
from collections import defaultdict, deque
from typing import Optional, Dict, List
import io

class UltimateFlex(commands.Cog):
    """🔥 The Ultimate Self-Bot Cog - Prepare to be amazed! 🔥"""

    def __init__(self, bot):
        self.bot = bot
        self.session = None

        # Sniper data
        self.deleted_messages = defaultdict(lambda: deque(maxlen=10))
        self.edited_messages = defaultdict(lambda: deque(maxlen=10))
        self.ghost_pings = defaultdict(list)

        # Auto-react system
        self.auto_react_users = {}  # user_id: [emojis]
        self.reaction_triggers = {}  # word: emoji

        # Message effects
        self.rainbow_mode = False
        self.typing_effect = False
        self.glitch_mode = False

        # Stats tracking
        self.message_stats = defaultdict(int)
        self.command_usage = defaultdict(int)
        self.last_seen = {}

        # Advanced features
        self.afk_mode = {'enabled': False, 'message': None, 'mentions': []}
        self.message_scheduler = {}
        self.encrypted_channels = set()

    async def cog_load(self):
        """Initialize the cog"""
        self.session = aiohttp.ClientSession()
        self.status_cycler.start()
        self.stats_updater.start()
        print("⚡ UltimateFlex Cog Loaded - Time to flex! 💪")

    async def cog_unload(self):
        """Cleanup"""
        self.status_cycler.cancel()
        self.stats_updater.cancel()
        if self.session:
            await self.session.close()

    # ============ SNIPER FEATURES ============

    @commands.command(name='snipe')
    async def snipe(self, ctx, index: int = 1):
        """Snipe deleted messages (up to 10 recent)"""
        self.command_usage['snipe'] += 1

        # Delete the command message for cleaner output
        try:
            await ctx.message.delete()
        except:
            pass

        if ctx.channel.id not in self.deleted_messages or not self.deleted_messages[ctx.channel.id]:
            return await ctx.send("❌ No deleted messages to snipe!", delete_after=5)

        try:
            msg_data = list(self.deleted_messages[ctx.channel.id])[-(index)]
            embed = discord.Embed(
                description=msg_data['content'],
                color=0xFF0000,
                timestamp=msg_data['deleted_at']
            )
            embed.set_author(name=f"{msg_data['author']} (Sniped)", icon_url=msg_data['avatar'])
            embed.set_footer(text=f"Message {index}/{len(self.deleted_messages[ctx.channel.id])}")
            await ctx.send(embed=embed)
        except IndexError:
            await ctx.send(f"❌ Only {len(self.deleted_messages[ctx.channel.id])} messages available!", delete_after=5)

    @commands.command(name='editsnipe', aliases=['esnipe'])
    async def edit_snipe(self, ctx):
        """Snipe edited messages"""
        self.command_usage['editsnipe'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        if ctx.channel.id not in self.edited_messages or not self.edited_messages[ctx.channel.id]:
            return await ctx.send("❌ No edited messages to snipe!", delete_after=5)

        msg_data = self.edited_messages[ctx.channel.id][-1]
        embed = discord.Embed(title="✏️ Edit Sniped", color=0xFFFF00)
        embed.add_field(name="Before", value=msg_data['before'][:1024], inline=False)
        embed.add_field(name="After", value=msg_data['after'][:1024], inline=False)
        embed.set_author(name=msg_data['author'], icon_url=msg_data['avatar'])
        embed.timestamp = msg_data['edited_at']
        await ctx.send(embed=embed)

    @commands.command(name='ghostping', aliases=['gp'])
    async def ghost_ping_detector(self, ctx):
        """Show recent ghost pings"""
        self.command_usage['ghostping'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        if ctx.channel.id not in self.ghost_pings or not self.ghost_pings[ctx.channel.id]:
            return await ctx.send("👻 No ghost pings detected!", delete_after=5)

        embed = discord.Embed(title="👻 Ghost Pings Detected!", color=0x9B59B6)
        for ping in self.ghost_pings[ctx.channel.id][-5:]:
            embed.add_field(
                name=f"{ping['author']} at {ping['time'].strftime('%H:%M:%S')}",
                value=ping['content'][:100],
                inline=False
            )
        await ctx.send(embed=embed)

    # ============ MESSAGE EFFECTS ============

    @commands.command(name='rainbow')
    async def rainbow_text(self, ctx, *, text: str):
        """Send text with rainbow effect (edits through colors)"""
        self.command_usage['rainbow'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        colors = ['❤️', '🧡', '💛', '💚', '💙', '💜']
        msg = await ctx.send(text)

        for _ in range(2):
            for color in colors:
                await msg.edit(content=f"{color} {text} {color}")
                await asyncio.sleep(0.5)
        await msg.edit(content=f"🌈 {text} 🌈")

    @commands.command(name='typewriter', aliases=['tw'])
    async def typewriter_effect(self, ctx, *, text: str):
        """Send message with typewriter effect"""
        self.command_usage['typewriter'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        msg = await ctx.send('_')
        typed = ""

        for char in text:
            typed += char
            await msg.edit(content=typed + '▌')
            await asyncio.sleep(random.uniform(0.05, 0.15))

        await msg.edit(content=typed)

    @commands.command(name='glitch')
    async def glitch_text(self, ctx, *, text: str):
        """Create glitched/zalgo text effect"""
        self.command_usage['glitch'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        glitch_chars = ['̸', '̷', '̶', '̴', '̵', '̡', '̢', '̧', '̨', '̛', '̖', '̗', '̘', '̙', '̜', '̝', '̞', '̟', '̠']
        glitched = ''.join(char + random.choice(glitch_chars) * random.randint(1, 3) for char in text)
        await ctx.send(f"```\n{glitched}\n```")

    @commands.command(name='ascii')
    async def ascii_art(self, ctx, *, text: str):
        """Convert text to ASCII art"""
        self.command_usage['ascii'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        # Simple ASCII art converter
        ascii_letters = {
            'A': '  ▄▄▄   \n ▐█▀█▌  \n▐█▄▄█▌  ',
            'B': '██████╗ \n██╔══██╗\n██████╔╝',
            'H': '██   ██ \n██   ██ \n███████ ',
            'I': '  ██  \n  ██  \n  ██  ',
            # Add more letters as needed
        }

        result = text.upper()
        output = ""
        for letter in result:
            if letter in ascii_letters:
                output = ascii_letters[letter]
                break

        if output:
            await ctx.send(f"```\n{output}\n```")
        else:
            await ctx.send(f"```\n{text}\n```")

    # ============ AUTO FEATURES ============

    @commands.command(name='autoreact')
    async def auto_react(self, ctx, user: discord.User, *emojis):
        """Auto-react to specific user's messages"""
        self.command_usage['autoreact'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        if not emojis:
            if user.id in self.auto_react_users:
                del self.auto_react_users[user.id]
                await ctx.send(f"✅ Stopped auto-reacting to {user.mention}", delete_after=5)
            else:
                await ctx.send("❌ Provide emojis to react with!", delete_after=5)
        else:
            self.auto_react_users[user.id] = list(emojis)[:5]  # Max 5 emojis
            await ctx.send(f"✅ Auto-reacting to {user.mention} with {' '.join(emojis[:5])}", delete_after=5)

    @commands.command(name='afk')
    async def afk_mode(self, ctx, *, message: str = None):
        """Enable AFK mode with custom message"""
        self.command_usage['afk2'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        self.afk_mode['enabled'] = not self.afk_mode['enabled']

        if self.afk_mode['enabled']:
            self.afk_mode['message'] = message or "I'm currently AFK!"
            self.afk_mode['mentions'] = []
            await ctx.send(f"😴 AFK Mode **enabled**: {self.afk_mode['message']}", delete_after=5)
        else:
            mentions = len(self.afk_mode['mentions'])
            await ctx.send(f"👋 Welcome back! You had {mentions} mentions while away.", delete_after=10)
            self.afk_mode['mentions'] = []

    # ============ UTILITY COMMANDS ============

    @commands.command(name='stats')
    async def user_stats(self, ctx, user: Optional[discord.User] = None):
        """Show detailed user statistics"""
        self.command_usage['stats'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        user = user or ctx.author

        embed = discord.Embed(
            title=f"📊 Stats for {user}",
            color=0x3498DB,
            timestamp=datetime.utcnow()
        )

        # Calculate stats
        mutual_guilds = sum(1 for guild in self.bot.guilds if user in guild.members)
        total_messages = self.message_stats.get(user.id, 0)
        last_seen_time = self.last_seen.get(user.id, "Never")

        embed.add_field(name="Account Created", value=f"<t:{int(user.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="User ID", value=f"`{user.id}`", inline=True)
        embed.add_field(name="Mutual Servers", value=mutual_guilds, inline=True)
        embed.add_field(name="Messages Tracked", value=total_messages, inline=True)
        embed.add_field(name="Last Seen", value=last_seen_time, inline=True)
        embed.add_field(name="Bot?", value="✅" if user.bot else "❌", inline=True)

        embed.set_thumbnail(url=user.avatar.url if user.avatar else user.default_avatar.url)
        embed.set_footer(text=f"Requested by {ctx.author}")

        await ctx.send(embed=embed)

    @commands.command(name='encode')
    async def encode_message(self, ctx, *, message: str):
        """Encode message in base64"""
        self.command_usage['encode'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        encoded = base64.b64encode(message.encode()).decode()
        await ctx.send(f"🔐 Encoded: `{encoded}`")

    @commands.command(name='decode')
    async def decode_message(self, ctx, *, encoded: str):
        """Decode base64 message"""
        self.command_usage['decode'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        try:
            decoded = base64.b64decode(encoded.encode()).decode()
            await ctx.send(f"🔓 Decoded: {decoded}")
        except:
            await ctx.send("❌ Invalid base64 string!", delete_after=5)

    @commands.command(name='schedule')
    async def schedule_message(self, ctx, delay: int, *, message: str):
        """Schedule a message (delay in seconds)"""
        self.command_usage['schedule'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        await ctx.send(f"⏰ Message scheduled in {delay} seconds", delete_after=3)
        await asyncio.sleep(delay)
        await ctx.send(message)

    # ============ FUN COMMANDS ============

    @commands.command(name='mock')
    async def mock_text(self, ctx, *, text: str):
        """MoCk TeXt LiKe SpOnGeBoB"""
        self.command_usage['mock'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        mocked = ''.join(char.upper() if i % 2 else char.lower() for i, char in enumerate(text))
        await ctx.send(mocked)

    @commands.command(name='reverse')
    async def reverse_text(self, ctx, *, text: str):
        """Reverse text completely"""
        self.command_usage['reverse'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        await ctx.send(text[::-1])

    @commands.command(name='clap')
    async def clap_text(self, ctx, *, text: str):
        """Add 👏 clap 👏 emojis 👏 between 👏 words"""
        self.command_usage['clap'] += 1

        try:
            await ctx.message.delete()
        except:
            pass

        clapped = ' 👏 '.join(text.split())
        await ctx.send(f"👏 {clapped} 👏")

    # ============ LISTENERS ============

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Track deleted messages"""
        if message.author.bot:
            return

        self.deleted_messages[message.channel.id].append({
            'content': message.content or '[Embed/Attachment]',
            'author': str(message.author),
            'avatar': message.author.avatar.url if message.author.avatar else message.author.default_avatar.url,
            'deleted_at': datetime.utcnow()
        })

        # Ghost ping detection
        if self.bot.user in message.mentions:
            self.ghost_pings[message.channel.id].append({
                'author': str(message.author),
                'content': message.content,
                'time': datetime.utcnow()
            })

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Track edited messages"""
        if before.author.bot or before.content == after.content:
            return

        self.edited_messages[before.channel.id].append({
            'before': before.content,
            'after': after.content,
            'author': str(before.author),
            'avatar': before.author.avatar.url if before.author.avatar else before.author.default_avatar.url,
            'edited_at': datetime.utcnow()
        })

    @commands.Cog.listener()
    async def on_message(self, message):
        """Track messages and handle auto features"""
        # Update stats for all messages
        self.message_stats[message.author.id] += 1
        self.last_seen[message.author.id] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

        # Skip our own messages to prevent loops
        if message.author == self.bot.user:
            return

        # Auto-react to specific users
        if message.author.id in self.auto_react_users:
            for emoji in self.auto_react_users[message.author.id]:
                try:
                    await message.add_reaction(emoji)
                    await asyncio.sleep(0.5)
                except:
                    pass

        # AFK mode handling
        if self.afk_mode['enabled'] and self.bot.user in message.mentions:
            self.afk_mode['mentions'].append({
                'author': str(message.author),
                'content': message.content,
                'time': datetime.utcnow()
            })
            await message.channel.send(
                f"{message.author.mention} {self.afk_mode['message']}",
                delete_after=10
            )

    # ============ BACKGROUND TASKS ============

    @tasks.loop(minutes=5)
    async def status_cycler(self):
        """Cycle through cool statuses"""
        statuses = [
            discord.Game("with the Ultimate Flex Cog 💪"),
            discord.Activity(type=discord.ActivityType.watching, name="for deleted messages 👀"),
            discord.Activity(type=discord.ActivityType.listening, name=".help"),
            discord.Streaming("Epic Coding", url="https://twitch.tv/placeholder"),
            discord.Activity(type=discord.ActivityType.competing, name="Hackathon 2025")
        ]

        await self.bot.change_presence(activity=random.choice(statuses))

    @tasks.loop(hours=1)
    async def stats_updater(self):
        """Update and save statistics periodically"""
        total_tracked = sum(self.message_stats.values())
        print(f"📊 Stats Update: Tracked {total_tracked} messages from {len(self.message_stats)} users")

    @status_cycler.before_loop
    async def before_status_loop(self):
        await self.bot.wait_until_ready()

    @stats_updater.before_loop
    async def before_stats_loop(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    # Check if cog is already loaded
    if 'UltimateFlex' in [cog for cog in bot.cogs]:
        print("⚠️ UltimateFlex is already loaded, skipping...")
        return

    await bot.add_cog(UltimateFlex(bot))
    print("🚀 UltimateFlex Cog has been added to the bot!")