from discord.ext import commands
import discord

class ResponseManagerCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Add response functionalities to bot
        self.bot.response_functionalities = {
            "edit_invoking": self._respond_edit_invoking,
            "send_in_invoking_channel": self._respond_send_in_channel,
            "reply_to_invoking": self._respond_reply_to_invoking
        }
        # Add respond method to bot
        self.bot.respond = self.respond
    
    async def _respond_edit_invoking(self, ctx, content, **kwargs):
        return await ctx.message.edit(content=content, **kwargs)
        
    async def _respond_send_in_channel(self, ctx, content, **kwargs):
        return await ctx.channel.send(content, **kwargs)
    
    async def _respond_reply_to_invoking(self, ctx, content, **kwargs):
        return await ctx.message.reply(content, **kwargs)
    
    async def respond(self, ctx, content, **kwargs):
        """Standardized response system for commands"""
        try:
            # Get response type from config, with fallback handling if Config cog is missing
            if hasattr(self.bot, 'get_config'):
                response_type = self.bot.get_config("command_response_type", "edit_invoking")
            else:
                # Direct config access if get_config isn't available
                self.bot.logger.warning("Config cog is not loaded, using direct config access")
                response_type = self.bot.config.get("command_response_type", "edit_invoking") if hasattr(self.bot, 'config') else "edit_invoking"
                
            if response_type in self.bot.response_functionalities:
                return await self.bot.response_functionalities[response_type](ctx, content, **kwargs)
            else:
                self.bot.logger.warning(f"Unknown response type '{response_type}', falling back to edit_invoking")
        except Exception as e:
            self.bot.logger.error(f"Error in respond: {e}, falling back to send_in_invoking_channel")
        
        # Fallback to edit_invoking in case of any issues
        return await self.bot.response_functionalities["send_in_invoking_channel"](ctx, content, **kwargs)

    @commands.command(hidden=True)
    async def response_type(self, ctx, type_name=None):
        """Set or view the current response type"""
        if type_name is None:
            current = self.bot.get_config("command_response_type", "edit_invoking")
            available = ", ".join(self.bot.response_functionalities.keys())
            await self.bot.respond(ctx, f"Current response type: `{current}`\nAvailable types: {available}")
            return
            
        if type_name not in self.bot.response_functionalities:
            available = ", ".join(self.bot.response_functionalities.keys())
            await self.bot.respond(ctx, f"Unknown response type: `{type_name}`\nAvailable types: {available}")
            return
            
        # Use the Config cog to set this
        config_cog = self.bot.get_cog("ConfigCog")
        if config_cog:
            await ctx.invoke(config_cog.set_config, "command_response_type", value=type_name)
        else:
            # Direct approach if Config cog is not loaded
            self.bot.config["command_response_type"] = type_name
            await self.bot.respond(ctx, f"Response type set to: `{type_name}`")

async def setup(bot):
    await bot.add_cog(ResponseManagerCog(bot))