# Discord Selfbot with Email AI Processor

## Overview
A Discord selfbot that monitors a Gmail inbox and uses AI (Groq/Gemini) to process emails and send notifications to a Discord channel or DM.

## Recent Changes
- Fixed ProtonEmailCog (Gmail checker) to use Groq with personality.json.
- Implemented smart fallback for email notifications (Channel -> DM -> Fallback Channel).
- Added `render.yaml` and `Procfile` for easy deployment to Render.com.

## User Preferences
- Uses "ukpkmkk_2" flirty personality.
- Minimal changes preferred.
- Responses should be channel/DM only, no user intent processing.

## Project Architecture
- `main.py`: Entry point for the Discord selfbot.
- `cogs/`: Contains modular features (Email checker, AI shapes, etc.).
- `personality.json`: Configures the AI's tone and behavior.
- `render.yaml`: Configuration for Render.com deployment.
