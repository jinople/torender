# TOML Configuration Guide

## Structure

The configuration file uses TOML format with three main sections:

1. `[metadata]` - Global configuration metadata
2. `[settings]` - The actual configuration values
3. `[value_metadata]` - Metadata for individual configuration keys

## Metadata

The global metadata section contains information about the configuration file itself:

```toml
[metadata]
# Configuration metadata
last_updated = "2025-05-17 12:00:00"  # When the config was last saved
version = "1.0"                      # Config file format version
last_modified_key = "afk_status"     # The most recently modified key (if applicable)
modified_by = "username"            # Who made the last change (if available)
```

Additional metadata may include:
- `hooks_passed` - List of hooks that were triggered during the last save
- `migration_source` - The source of a configuration migration

## Settings

The settings section contains all the actual configuration values:

```toml
[settings]
# User settings
command_response_type = "edit_invoking"
afk_status_message = "AFK!"
# ... other settings
```

## Value Metadata

This section stores metadata for individual configuration keys:

```toml
[value_metadata]
# Individual value metadata

[value_metadata.afk_status_message]
last_updated = "2025-05-17 12:00:00"
updated_by = "glitchy#1234 (123456789012345678)"

[value_metadata.command_response_type]
last_updated = "2025-05-17 12:00:00"
updated_by = "system"
```

## Commands

The following commands help manage and inspect the configuration:

- `.show_config` - Shows all configuration settings with their descriptions
- `.set_config key value` - Sets a configuration value with full metadata tracking
- `.config_meta` - Shows global configuration metadata
- `.config_meta key` - Shows detailed metadata for a specific configuration key
- `.migrate_config` - Manually triggers migration from JSON to TOML format

## Testing

To test your TOML configuration, run the included test script:

```bash
./test_toml_config.py
```

This script can help diagnose and fix issues with the TOML format, and performs migration from JSON to TOML if needed.